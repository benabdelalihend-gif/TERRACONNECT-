<?php
/** @var string $titre */
/** @var string $actif  'plantations' | 'suivi' */
require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf" content="<?= h(csrf_token()) ?>">
    <title>TerraConnect - <?= h($titre) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<aside class="sidebar">
    <a class="logo" href="plantations.php"><img src="assets/img/logo.png" alt="Logo TerraConnect" onerror="this.style.display='none'"><span>TerraConnect</span></a>
    <nav>
        <a class="lien<?= $actif === 'plantations' ? ' actif' : '' ?>" href="plantations.php"><i class="fa-solid fa-seedling"></i> Plantations</a>
        <a class="lien sous-lien<?= $actif === 'suivi' ? ' actif' : '' ?>" href="suivi.php"><i class="fa-solid fa-clipboard-list"></i> Suivi</a>
    </nav>
</aside>

<div class="contenu">
<main>
