</main>

<footer>&copy; <?= date('Y') ?> TerraConnect - Agriculture durable</footer>
</div>

</body>
</html>
