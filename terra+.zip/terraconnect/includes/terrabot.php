<?php
require_once __DIR__ . '/functions.php';

/**
 * TerraBot - assistant agricole.
 * Génère des conseils personnalisés à partir :
 *  - de la catégorie de plante et de l'état de la plantation,
 *  - du dernier état de santé constaté,
 *  - de l'historique des opérations (arrosage en retard, absence d'observation...),
 *  - de la base de conseils (table conseils_terrabot).
 */

const THEMES_TERRABOT = ['general', 'irrigation', 'entretien', 'croissance', 'sante', 'recolte'];

/** Devine le thème d'une question libre à partir de mots-clés. */
function terrabot_detecter_theme(string $question): string
{
    $q = mb_strtolower($question, 'UTF-8');
    $mots = [
        'irrigation' => ['arros', 'eau', 'irrig', 'sécheresse', 'secheresse', 'goutte', 'humidit'],
        'entretien'  => ['entretien', 'taille', 'tailler', 'engrais', 'fertili', 'désherb', 'desherb', 'fumure', 'paill'],
        'croissance' => ['croissance', 'pousse', 'grandi', 'jaun', 'feuille', 'floraison', 'fleur', 'développ', 'develop'],
        'sante'      => ['malad', 'santé', 'sante', 'ravageur', 'insecte', 'puceron', 'champignon', 'traitement', 'tache', 'flétri', 'fletri', 'mildiou'],
        'recolte'    => ['récolte', 'recolte', 'cueill', 'maturité', 'maturite', 'moisson', 'vendange'],
    ];
    foreach ($mots as $theme => $liste) {
        foreach ($liste as $m) {
            if (mb_strpos($q, $m) !== false) return $theme;
        }
    }
    return 'general';
}

/** Alertes calculées à partir de l'historique. */
function terrabot_alertes(array $p, ?string $sante): array
{
    $alertes = [];
    if ($p['etat'] === 'Récoltée') return $alertes;

    $pdo = db();
    $today = new DateTime('today');
    $id = (int)$p['id_plantation'];

    // Arrosage
    $st = $pdo->prepare("SELECT MAX(date_suivi) FROM suivis WHERE id_plantation = ? AND type_intervention = 'Arrosage'");
    $st->execute([$id]);
    $dernierArrosage = $st->fetchColumn();
    $ref = $dernierArrosage ?: $p['date_plantation'];
    $refDate = new DateTime($ref);
    if ($refDate <= $today) {
        $jours = (int)$refDate->diff($today)->days;
        $freq = max(1, (int)$p['frequence_arrosage_jours']);
        $quand = $dernierArrosage ? "dernier arrosage il y a $jours jour(s)" : "aucun arrosage enregistré depuis la plantation ($jours jour(s))";
        if ($jours > $freq * 1.5) {
            $alertes[] = ['niveau' => 'haute', 'titre' => 'Arrosage en retard',
                'texte' => "Pour un " . mb_strtolower($p['culture'], 'UTF-8') . ", un arrosage est conseillé environ tous les $freq jours : $quand. Vérifiez l'humidité du sol et arrosez si nécessaire (sauf si la pluie a suffi)."];
        } elseif ($jours >= $freq) {
            $alertes[] = ['niveau' => 'moyenne', 'titre' => 'Arrosage à prévoir',
                'texte' => "Arrosage conseillé tous les $freq jours : $quand. Pensez à planifier une irrigation prochainement."];
        }
    }

    // Dernière observation
    $st = $pdo->prepare('SELECT MAX(date_suivi) FROM suivis WHERE id_plantation = ?');
    $st->execute([$id]);
    $dernier = $st->fetchColumn();
    if (!$dernier) {
        $alertes[] = ['niveau' => 'moyenne', 'titre' => 'Aucun suivi enregistré',
            'texte' => "Ajoutez un premier suivi (observation, arrosage…) pour que TerraBot puisse évaluer l'état de la plantation."];
    } else {
        $dd = new DateTime($dernier);
        if ($dd <= $today && (int)$dd->diff($today)->days > 15) {
            $alertes[] = ['niveau' => 'moyenne', 'titre' => 'Suivi ancien',
                'texte' => "Le dernier suivi date de " . (int)$dd->diff($today)->days . " jours. Une observation régulière (tous les 15 jours environ) permet de repérer tôt les problèmes."];
        }
    }

    if ($sante === 'Mauvais') {
        $alertes[] = ['niveau' => 'haute', 'titre' => 'État de santé mauvais',
            'texte' => "Le dernier état constaté est « Mauvais ». Une inspection rapide de la parcelle est recommandée."];
    }

    // Récolte proche
    if (!empty($p['date_recolte_prevue']) && $p['etat'] !== 'Prête à récolter') {
        $dr = new DateTime($p['date_recolte_prevue']);
        $reste = (int)$today->diff($dr)->format('%r%a');
        if ($reste >= 0 && $reste <= 15) {
            $alertes[] = ['niveau' => 'moyenne', 'titre' => 'Récolte proche',
                'texte' => "La récolte est prévue dans $reste jour(s). Préparez le matériel et la main-d'œuvre."];
        }
    }
    return $alertes;
}

/** Conseils de la base correspondant à la plantation. */
function terrabot_conseils(array $p, ?string $sante, string $theme): array
{
    $sql = 'SELECT titre, conseil, theme, priorite, id_categorie
            FROM conseils_terrabot
            WHERE (id_categorie IS NULL OR id_categorie = :cat)
              AND (etat_constate IS NULL OR etat_constate = :sante)
              AND (etat_plantation IS NULL OR etat_plantation = :etat)';
    $params = [':cat' => (int)$p['id_categorie'], ':sante' => $sante ?? '', ':etat' => $p['etat']];
    if ($theme !== 'general') {
        $sql .= ' AND theme = :theme';
        $params[':theme'] = $theme;
    }
    // Les conseils propres à la plante passent avant les conseils généraux
    $sql .= ' ORDER BY priorite ASC, (id_categorie IS NULL) ASC, id_conseil ASC LIMIT 6';
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

/** Point d'entrée : construit la réponse complète de TerraBot. */
function terrabot_repondre(int $idPlantation, string $theme = 'general', string $question = ''): ?array
{
    $p = plantation_par_id($idPlantation);
    if (!$p) return null;

    if (!in_array($theme, THEMES_TERRABOT, true)) $theme = 'general';
    if ($question !== '' && $theme === 'general') $theme = terrabot_detecter_theme($question);

    $sante = sante_actuelle($idPlantation);
    $alertes = terrabot_alertes($p, $sante);
    $conseils = terrabot_conseils($p, $sante, $theme);

    $nomPlante = mb_strtolower($p['culture'], 'UTF-8');
    $introSante = $sante ? "état de santé « $sante »" : 'état de santé non évalué';
    $message = "Plantation de $nomPlante à " . $p['localisation'] . ' (' . mb_strtolower($p['etat'], 'UTF-8') . ', ' . $introSante . ').';
    if ($theme !== 'general') {
        $libelles = ['irrigation' => "l'irrigation", 'entretien' => "l'entretien", 'croissance' => 'la croissance', 'sante' => 'la santé des plants', 'recolte' => 'la récolte'];
        $message .= ' Voici mes recommandations sur ' . $libelles[$theme] . '.';
    } else {
        $message .= ' Voici mes recommandations générales.';
    }
    if (!$conseils && !$alertes) {
        $message .= " Je n'ai pas de conseil précis pour cette combinaison : ajoutez un suivi récent pour que je puisse mieux vous aider.";
    }

    // Les alertes liées à l'arrosage n'ont de sens que pour les thèmes irrigation/général/santé
    if ($theme === 'entretien' || $theme === 'recolte') {
        $alertes = array_values(array_filter($alertes, function ($a) { return stripos($a['titre'], 'arrosage') === false; }));
    }

    $reponse = [
        'plantation' => ['id' => (int)$p['id_plantation'], 'culture' => $p['culture'], 'localisation' => $p['localisation'], 'etat' => $p['etat'], 'sante' => $sante],
        'theme'      => $theme,
        'message'    => $message,
        'alertes'    => $alertes,
        'conseils'   => array_map(function ($c) { return ['titre' => $c['titre'], 'conseil' => $c['conseil'], 'theme' => $c['theme']]; }, $conseils),
    ];

    // Historique des échanges
    $texte = $message;
    foreach ($alertes as $a) $texte .= "\n[Alerte] " . $a['titre'] . ' : ' . $a['texte'];
    foreach ($conseils as $c) $texte .= "\n- " . $c['titre'] . ' : ' . $c['conseil'];
    $st = db()->prepare('INSERT INTO terrabot_messages (id_plantation, theme, question, reponse) VALUES (?,?,?,?)');
    $st->execute([$idPlantation, $theme, $question !== '' ? mb_substr($question, 0, 300) : null, $texte]);

    return $reponse;
}
