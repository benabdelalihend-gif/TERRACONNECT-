<?php
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

const ETATS_PLANTATION = ['En préparation', 'En croissance', 'Prête à récolter', 'Récoltée'];
const TYPES_INTERVENTION = ['Arrosage', 'Fertilisation', 'Traitement', 'Désherbage', 'Taille', 'Observation', 'Récolte'];
const ETATS_SANTE = ['Bon', 'Moyen', 'Mauvais'];
const UNITES = ['L', 'kg', 't'];

/** Échappe pour l'affichage HTML. */
function h($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function fmt_date(?string $d): string
{
    if (!$d) return '-';
    $t = DateTime::createFromFormat('Y-m-d', substr($d, 0, 10));
    return $t ? $t->format('d/m/Y') : '-';
}

/** 5.5 -> "5,5" ; 2.00 -> "2" */
function fmt_num($n, int $dec = 2): string
{
    $s = number_format((float)$n, $dec, ',', ' ');
    if (strpos($s, ',') !== false) {
        $s = rtrim(rtrim($s, '0'), ',');
    }
    return $s;
}

function valid_date(?string $d): bool
{
    if (!$d) return false;
    $t = DateTime::createFromFormat('Y-m-d', $d);
    return $t && $t->format('Y-m-d') === $d;
}

/* ---------- Messages flash ---------- */
function flash(string $msg, string $type = 'ok'): void
{
    $_SESSION['flash'][] = ['msg' => $msg, 'type' => $type];
}

function flash_render(): string
{
    if (empty($_SESSION['flash'])) return '';
    $out = '';
    foreach ($_SESSION['flash'] as $f) {
        $cls = $f['type'] === 'err' ? ' erreur' : '';
        $out .= '<div class="message visible' . $cls . '" role="status">' . h($f['msg']) . '</div>';
    }
    unset($_SESSION['flash']);
    return $out;
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}

function csrf_ok(?string $t): bool
{
    return !empty($_SESSION['csrf']) && is_string($t) && hash_equals($_SESSION['csrf'], $t);
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/* ---------- Libellés / classes CSS ---------- */
function classe_etat(string $etat): string
{
    switch ($etat) {
        case 'En préparation':   return 'prep';
        case 'En croissance':    return 'crois';
        case 'Prête à récolter': return 'recolte';
        default:                 return 'finie';
    }
}

function classe_sante(?string $s): string
{
    switch ($s) {
        case 'Bon':     return 'bon';
        case 'Moyen':   return 'moyen';
        case 'Mauvais': return 'mauvais';
        default:        return 'finie';
    }
}

function icone_intervention(string $t): string
{
    $m = [
        'Arrosage' => 'fa-droplet', 'Fertilisation' => 'fa-flask', 'Traitement' => 'fa-spray-can-sparkles',
        'Désherbage' => 'fa-broom', 'Taille' => 'fa-scissors', 'Observation' => 'fa-eye', 'Récolte' => 'fa-basket-shopping',
    ];
    return $m[$t] ?? 'fa-circle';
}

/**
 * Avancement (%) d'une plantation : temps écoulé entre la plantation et la récolte prévue
 * (ou, à défaut, la durée du cycle de la catégorie).
 */
function avancement(array $p): int
{
    if (($p['etat'] ?? '') === 'Récoltée') return 100;
    $debut = strtotime($p['date_plantation']);
    if (!empty($p['date_recolte_prevue'])) {
        $fin = strtotime($p['date_recolte_prevue']);
    } else {
        $fin = $debut + ((int)($p['duree_cycle_jours'] ?? 365)) * 86400;
    }
    if ($fin <= $debut) return 0;
    $pct = (time() - $debut) / ($fin - $debut) * 100;
    return (int)max(0, min(99, round($pct)));
}

/** Date de récolte par défaut = plantation + durée du cycle. */
function date_recolte_defaut(string $datePlantation, int $cycleJours): string
{
    return date('Y-m-d', strtotime($datePlantation) + $cycleJours * 86400);
}

/* ---------- Accès données ---------- */
function categories(): array
{
    return db()->query('SELECT * FROM categories_plantes ORDER BY nom')->fetchAll();
}

function plantation_par_id(int $id): ?array
{
    $st = db()->prepare(
        'SELECT p.*, c.nom AS culture, c.icone, c.type_culture, c.duree_cycle_jours, c.frequence_arrosage_jours
         FROM plantations p JOIN categories_plantes c ON c.id_categorie = p.id_categorie
         WHERE p.id_plantation = ?'
    );
    $st->execute([$id]);
    $r = $st->fetch();
    return $r ?: null;
}

function sante_actuelle(int $idPlantation): ?string
{
    $st = db()->prepare('SELECT etat_constate FROM suivis WHERE id_plantation = ? ORDER BY date_suivi DESC, id_suivi DESC LIMIT 1');
    $st->execute([$idPlantation]);
    $v = $st->fetchColumn();
    return $v === false ? null : $v;
}

/** Supprime le fichier photo d'un suivi s'il existe. */
function supprimer_photo(?string $fichier): void
{
    if ($fichier && preg_match('/^[a-f0-9]{32}\.(jpg|png|webp|gif)$/', $fichier)) {
        $chemin = UPLOAD_DIR . $fichier;
        if (is_file($chemin)) @unlink($chemin);
    }
}

/** Enregistre une photo envoyée ; retourne [nomFichier|null, erreur|null]. */
function enregistrer_photo(array $f): array
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [null, null];
    if ($f['error'] !== UPLOAD_ERR_OK) return [null, "Échec de l'envoi de la photo."];
    if ($f['size'] > UPLOAD_MAX_BYTES) return [null, 'La photo dépasse 3 Mo.'];
    $mimes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    if (!isset($mimes[$mime])) return [null, 'Format de photo non accepté (JPG, PNG, WebP ou GIF).'];
    if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);
    $nom = bin2hex(random_bytes(16)) . '.' . $mimes[$mime];
    if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . $nom)) return [null, "Impossible d'enregistrer la photo."];
    return [$nom, null];
}
