-- ============================================================
-- TerraConnect - Plantations, Suivi et TerraBot
-- Base de données MySQL / MariaDB (InnoDB, utf8mb4)
-- Import : mysql -u root -p < database/terraconnect.sql
--          (ou via phpMyAdmin > Importer)
-- ============================================================

CREATE DATABASE IF NOT EXISTS terraconnect
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE terraconnect;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
DROP VIEW  IF EXISTS v_plantations_sante;
DROP TABLE IF EXISTS terrabot_messages;
DROP TABLE IF EXISTS conseils_terrabot;
DROP TABLE IF EXISTS suivis;
DROP TABLE IF EXISTS plantations;
DROP TABLE IF EXISTS categories_plantes;
SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
-- 1. Catégories de plantes
-- ------------------------------------------------------------
CREATE TABLE categories_plantes (
  id_categorie            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nom                     VARCHAR(60)  NOT NULL,
  type_culture            ENUM('Arbre fruitier','Maraîchage','Céréale','Vigne') NOT NULL,
  description             VARCHAR(500) NULL,
  icone                   VARCHAR(40)  NOT NULL DEFAULT 'fa-seedling',
  duree_cycle_jours       SMALLINT UNSIGNED NOT NULL DEFAULT 365,   -- plantation -> récolte (valeur indicative)
  frequence_arrosage_jours SMALLINT UNSIGNED NOT NULL DEFAULT 7,    -- intervalle d'arrosage conseillé
  saison_plantation       VARCHAR(60)  NULL,
  saison_recolte          VARCHAR(60)  NULL,
  PRIMARY KEY (id_categorie),
  UNIQUE KEY uq_categorie_nom (nom)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 2. Plantations
-- ------------------------------------------------------------
CREATE TABLE plantations (
  id_plantation       INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_categorie        INT UNSIGNED NOT NULL,
  superficie_ha       DECIMAL(10,2) NOT NULL,
  date_plantation     DATE NOT NULL,
  date_recolte_prevue DATE NULL,
  localisation        VARCHAR(100) NOT NULL,
  etat                ENUM('En préparation','En croissance','Prête à récolter','Récoltée') NOT NULL DEFAULT 'En préparation',
  created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_plantation),
  KEY idx_plantations_categorie (id_categorie),
  KEY idx_plantations_etat (etat),
  CONSTRAINT fk_plantations_categorie FOREIGN KEY (id_categorie)
    REFERENCES categories_plantes (id_categorie) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT chk_superficie CHECK (superficie_ha > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 3. Suivis (historique des opérations agricoles et état de santé)
-- ------------------------------------------------------------
CREATE TABLE suivis (
  id_suivi          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_plantation     INT UNSIGNED NOT NULL,
  date_suivi        DATE NOT NULL,
  type_intervention ENUM('Arrosage','Fertilisation','Traitement','Désherbage','Taille','Observation','Récolte') NOT NULL,
  etat_constate     ENUM('Bon','Moyen','Mauvais') NOT NULL,   -- état de santé constaté
  quantite          DECIMAL(10,2) NULL,
  unite             ENUM('L','kg','t') NULL,
  photo             VARCHAR(255) NULL,
  description       VARCHAR(300) NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_suivi),
  KEY idx_suivis_plantation_date (id_plantation, date_suivi),
  KEY idx_suivis_type (type_intervention),
  CONSTRAINT fk_suivis_plantation FOREIGN KEY (id_plantation)
    REFERENCES plantations (id_plantation) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 4. Base de conseils de TerraBot
--    id_categorie NULL     = conseil valable pour toutes les plantes
--    etat_constate NULL    = valable quel que soit l'état de santé
--    etat_plantation NULL  = valable à tous les stades
--    priorite : 1 (haute) à 3 (basse)
-- ------------------------------------------------------------
CREATE TABLE conseils_terrabot (
  id_conseil      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_categorie    INT UNSIGNED NULL,
  theme           ENUM('irrigation','entretien','croissance','sante','recolte') NOT NULL,
  etat_constate   ENUM('Bon','Moyen','Mauvais') NULL,
  etat_plantation ENUM('En préparation','En croissance','Prête à récolter','Récoltée') NULL,
  titre           VARCHAR(120) NOT NULL,
  conseil         TEXT NOT NULL,
  priorite        TINYINT UNSIGNED NOT NULL DEFAULT 2,
  PRIMARY KEY (id_conseil),
  KEY idx_conseils_recherche (id_categorie, theme),
  CONSTRAINT fk_conseils_categorie FOREIGN KEY (id_categorie)
    REFERENCES categories_plantes (id_categorie) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 5. Historique des échanges avec TerraBot
-- ------------------------------------------------------------
CREATE TABLE terrabot_messages (
  id_message    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_plantation INT UNSIGNED NOT NULL,
  theme         VARCHAR(20)  NOT NULL,
  question      VARCHAR(300) NULL,
  reponse       TEXT NOT NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_message),
  KEY idx_messages_plantation (id_plantation, created_at),
  CONSTRAINT fk_messages_plantation FOREIGN KEY (id_plantation)
    REFERENCES plantations (id_plantation) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 6. Vue : plantation + catégorie + dernier état de santé
-- ------------------------------------------------------------
CREATE VIEW v_plantations_sante AS
SELECT p.id_plantation, p.id_categorie, c.nom AS culture, c.icone,
       p.superficie_ha, p.date_plantation, p.date_recolte_prevue,
       p.localisation, p.etat,
       (SELECT s.etat_constate FROM suivis s WHERE s.id_plantation = p.id_plantation
         ORDER BY s.date_suivi DESC, s.id_suivi DESC LIMIT 1) AS sante,
       (SELECT s.date_suivi FROM suivis s WHERE s.id_plantation = p.id_plantation
         ORDER BY s.date_suivi DESC, s.id_suivi DESC LIMIT 1) AS dernier_suivi,
       (SELECT COUNT(*) FROM suivis s WHERE s.id_plantation = p.id_plantation) AS nb_interventions
FROM plantations p
JOIN categories_plantes c ON c.id_categorie = p.id_categorie;

-- ============================================================
-- DONNÉES INITIALES
-- ============================================================

INSERT INTO categories_plantes
(id_categorie, nom, type_culture, description, icone, duree_cycle_jours, frequence_arrosage_jours, saison_plantation, saison_recolte) VALUES
(1, 'Olivier',   'Arbre fruitier', 'Arbre rustique méditerranéen, tolérant à la sécheresse, cultivé pour les olives et l''huile.', 'fa-tree', 365, 14, 'Automne - début d''hiver', 'Novembre - janvier'),
(2, 'Tomate',    'Maraîchage',     'Culture maraîchère exigeante en eau et en suivi sanitaire.', 'fa-apple-whole', 110, 3, 'Printemps ou automne', 'Environ 3 à 4 mois après plantation'),
(3, 'Blé',       'Céréale',        'Céréale d''hiver cultivée en grande parcelle.', 'fa-wheat-awn', 210, 15, 'Automne', 'Mai - juin'),
(4, 'Vigne',     'Vigne',          'Culture pérenne conduite en rangs palissés.', 'fa-wine-glass', 180, 10, 'Hiver - début de printemps', 'Août - octobre'),
(5, 'Amandier',  'Arbre fruitier', 'Arbre à floraison très précoce, résistant à la sécheresse, sensible aux gelées tardives.', 'fa-tree', 300, 14, 'Automne - hiver', 'Août - septembre'),
(6, 'Citronnier','Arbre fruitier', 'Agrume sensible au froid et à l''excès d''eau, besoin d''arrosages réguliers.', 'fa-lemon', 365, 5, 'Printemps ou début d''automne', 'Toute l''année selon variété (pic en hiver)'),
(7, 'Grenadier', 'Arbre fruitier', 'Arbuste fruitier rustique, tolère la chaleur et une certaine salinité.', 'fa-tree', 270, 10, 'Fin d''hiver - printemps', 'Octobre - novembre');

INSERT INTO plantations (id_plantation, id_categorie, superficie_ha, date_plantation, date_recolte_prevue, localisation, etat) VALUES
(1, 1, 2.00, '2026-10-05', '2027-10-05', 'Ariana',  'En croissance'),
(2, 2, 1.00, '2026-09-15', '2027-01-03', 'Manouba', 'Prête à récolter'),
(3, 3, 5.50, '2026-11-02', '2027-05-31', 'Béja',    'En préparation');

INSERT INTO suivis (id_plantation, date_suivi, type_intervention, etat_constate, quantite, unite, description) VALUES
(1, '2026-10-12', 'Arrosage',      'Bon',   800.00, 'L',  'Irrigation goutte à goutte'),
(1, '2026-10-25', 'Fertilisation', 'Bon',   40.00,  'kg', 'Apport d''engrais organique'),
(2, '2026-10-01', 'Traitement',    'Moyen', NULL,   NULL, 'Traitement préventif contre le mildiou'),
(2, '2026-11-10', 'Observation',   'Bon',   NULL,   NULL, 'Fruits mûrs, récolte à planifier'),
(3, '2026-11-05', 'Observation',   'Bon',   NULL,   NULL, 'Préparation du sol terminée');

-- ------------------------------------------------------------
-- Conseils TerraBot
-- ------------------------------------------------------------

-- Conseils généraux (toutes plantes)
INSERT INTO conseils_terrabot (id_categorie, theme, etat_constate, etat_plantation, titre, conseil, priorite) VALUES
(NULL,'sante','Mauvais',NULL,'Inspection urgente','Inspectez la parcelle dans les 48 heures : notez les symptômes (jaunissement, taches, flétrissement, insectes), prenez des photos et ajoutez un suivi « Observation ». En cas de doute, demandez l''avis d''un technicien agricole avant tout traitement.',1),
(NULL,'sante','Moyen',NULL,'Surveillance renforcée','L''état est moyen : refaites une observation dans la semaine, vérifiez l''humidité du sol et l''absence de ravageurs, puis comparez avec le dernier suivi.',2),
(NULL,'sante','Bon',NULL,'Continuer le programme','L''état est bon. Maintenez le calendrier d''arrosage et de fertilisation et poursuivez des observations régulières (au moins tous les 15 jours).',3),
(NULL,'entretien',NULL,'En préparation','Préparer le terrain','Avant la plantation : travail du sol, apport de fumure de fond, vérification du drainage et du système d''irrigation.',2),
(NULL,'croissance',NULL,'En préparation','Préparer la reprise','Choisissez des plants sains, plantez à la bonne profondeur et arrosez abondamment juste après la plantation pour favoriser la reprise.',2),
(NULL,'recolte',NULL,'Prête à récolter','Planifier la récolte','La plantation est prête à récolter : prévoyez la main-d''œuvre, le matériel et le stockage, et choisissez une journée sèche.',1),
(NULL,'entretien',NULL,'Récoltée','Après la récolte','Nettoyez la parcelle, retirez les résidus malades, faites un apport de fumure et notez le rendement obtenu pour le comparer à la saison suivante.',2);

-- Olivier (1)
INSERT INTO conseils_terrabot (id_categorie, theme, etat_constate, etat_plantation, titre, conseil, priorite) VALUES
(1,'irrigation',NULL,NULL,'Irrigation d''appoint','L''olivier supporte la sécheresse mais les jeunes plants ont besoin d''eau : arrosez en profondeur, environ toutes les 2 semaines en été, plutôt que souvent et en surface. Évitez l''excès d''eau qui asphyxie les racines.',1),
(1,'entretien',NULL,NULL,'Taille et fertilisation','Taille de formation légère en fin d''hiver, désherbage au pied des arbres et apport de fumure organique à l''automne.',2),
(1,'croissance',NULL,'En croissance','Jeunes oliviers','Posez un tuteur et protégez du vent les jeunes plants. La croissance est lente la première année : ne forcez pas avec trop d''azote.',2),
(1,'sante','Mauvais',NULL,'Maladies de l''olivier','Surveillez l''œil de paon (taches circulaires sur feuilles), la cochenille noire et la mouche de l''olive. Un traitement cuivré après la taille limite les maladies fongiques.',1),
(1,'recolte',NULL,'Prête à récolter','Récolte des olives','Récoltez selon l''usage (olives de table ou huile) en évitant de blesser les fruits, et pressez rapidement pour préserver la qualité de l''huile.',2);

-- Tomate (2)
INSERT INTO conseils_terrabot (id_categorie, theme, etat_constate, etat_plantation, titre, conseil, priorite) VALUES
(2,'irrigation',NULL,NULL,'Arrosage régulier','La tomate demande une humidité régulière : arrosage fréquent (tous les 2 à 3 jours selon la chaleur), de préférence en goutte à goutte et le matin, sans mouiller le feuillage. Les à-coups d''irrigation font éclater les fruits.',1),
(2,'entretien',NULL,NULL,'Tuteurage et ébourgeonnage','Tuteurez les plants, supprimez les gourmands et apportez une fertilisation riche en potassium au moment de la floraison-fructification.',2),
(2,'croissance',NULL,'En croissance','Conduite de la culture','Aérez les plants et paillez le sol pour limiter les maladies et conserver l''humidité.',2),
(2,'sante','Mauvais',NULL,'Mildiou et ravageurs','Taches brunes sur feuilles ou fruits : suspectez le mildiou. Retirez les parties atteintes, aérez la culture et traitez selon les recommandations locales. Surveillez aussi les aleurodes et Tuta absoluta.',1),
(2,'recolte',NULL,'Prête à récolter','Récolte des tomates','Récoltez les fruits à maturité, régulièrement, de préférence aux heures fraîches de la journée.',2);

-- Blé (3)
INSERT INTO conseils_terrabot (id_categorie, theme, etat_constate, etat_plantation, titre, conseil, priorite) VALUES
(3,'irrigation',NULL,NULL,'Irrigation du blé','Culture surtout pluviale : une irrigation de complément (environ toutes les 2 semaines en l''absence de pluie) est utile aux stades critiques, notamment au tallage et à l''épiaison.',2),
(3,'entretien',NULL,NULL,'Désherbage et fertilisation','Désherbez tôt dans le cycle et fractionnez l''apport d''azote (tallage, montaison) pour éviter les pertes.',2),
(3,'croissance',NULL,'En préparation','Semis','Semez sur un sol bien préparé et ameubli, à une densité adaptée à la variété, après les premières pluies d''automne.',2),
(3,'sante','Mauvais',NULL,'Maladies des céréales','Surveillez la rouille jaune, la septoriose et les pucerons. Intervenez tôt et faites identifier la maladie avant de traiter.',1),
(3,'recolte',NULL,'Prête à récolter','Moisson','Moissonnez quand le grain est sec et dur, par temps sec, pour limiter les pertes et les risques de moisissures au stockage.',2);

-- Vigne (4)
INSERT INTO conseils_terrabot (id_categorie, theme, etat_constate, etat_plantation, titre, conseil, priorite) VALUES
(4,'irrigation',NULL,NULL,'Irrigation de la vigne','Arrosage modéré (environ toutes les 10 jours en été pour les jeunes plants), à réduire avant la maturité pour concentrer les sucres.',2),
(4,'entretien',NULL,NULL,'Taille et palissage','Taille d''hiver, relevage et palissage de la végétation en saison, désherbage sous le rang.',2),
(4,'sante','Mauvais',NULL,'Maladies de la vigne','Surveillez le mildiou, l''oïdium et le botrytis. Aérez la végétation et traitez de manière préventive selon les conditions climatiques.',1),
(4,'recolte',NULL,'Prête à récolter','Vendanges','Vendangez à maturité (suivi du degré et de l''acidité), de préférence aux heures fraîches.',2);

-- Amandier (5)
INSERT INTO conseils_terrabot (id_categorie, theme, etat_constate, etat_plantation, titre, conseil, priorite) VALUES
(5,'irrigation',NULL,NULL,'Irrigation de l''amandier','Arbre résistant à la sécheresse : arrosage modéré (environ toutes les 2 semaines en été), à privilégier au printemps pendant la nouaison et le remplissage de l''amande. Réduisez l''eau avant la récolte et évitez tout sol détrempé.',1),
(5,'entretien',NULL,NULL,'Taille et fertilisation','Taille de formation en gobelet en hiver, désherbage au pied, apport d''azote au printemps et de potasse pour la qualité des fruits. Un traitement cuivré avant le débourrement limite la moniliose et la cloque.',2),
(5,'croissance',NULL,'En croissance','Floraison précoce','L''amandier fleurit très tôt (janvier-février) et craint les gelées tardives : évitez les bas-fonds froids et surveillez les prévisions météo pendant la floraison.',2),
(5,'sante','Mauvais',NULL,'Moniliose et ravageurs','Rameaux desséchés, fleurs ou jeunes fruits qui brunissent : suspectez la moniliose. Coupez et éliminez les parties atteintes, puis traitez au cuivre selon les conseils locaux. Surveillez aussi les pucerons et les acariens.',1),
(5,'recolte',NULL,'Prête à récolter','Récolte des amandes','Récoltez quand le brou s''ouvre et se fend (août-septembre), puis séchez les amandes rapidement pour éviter les moisissures.',2);

-- Citronnier (6)
INSERT INTO conseils_terrabot (id_categorie, theme, etat_constate, etat_plantation, titre, conseil, priorite) VALUES
(6,'irrigation',NULL,NULL,'Irrigation du citronnier','Le citronnier préfère des arrosages réguliers et modérés : environ tous les 3 à 5 jours en été (goutte à goutte idéal), moins en hiver. Le sol doit rester frais mais jamais détrempé, un manque d''eau provoque la chute des fleurs et des fruits. Un paillage limite l''évaporation.',1),
(6,'entretien',NULL,NULL,'Fertilisation et taille','Apportez un engrais riche en azote avec des oligo-éléments (fer, magnésium, zinc) plusieurs fois par an. Faites une taille légère d''aération après la récolte et protégez les jeunes arbres du froid.',2),
(6,'croissance',NULL,'En croissance','Feuilles jaunes','Des feuilles jaunes aux nervures vertes indiquent souvent une chlorose ferrique : apport de fer chélaté. Des feuilles jaunes uniformes peuvent signaler un excès d''eau ou un manque d''azote.',2),
(6,'sante','Mauvais',NULL,'Ravageurs et gommose','Surveillez cochenilles, aleurodes et mineuse des agrumes (traitement à l''huile blanche possible). Des écoulements de gomme au collet indiquent un excès d''eau : améliorez le drainage et dégagez le collet.',1),
(6,'recolte',NULL,'Prête à récolter','Récolte des citrons','Récoltez les fruits lorsqu''ils ont atteint leur couleur et leur calibre, en coupant le pédoncule avec un sécateur plutôt qu''en arrachant.',2);

-- Grenadier (7)
INSERT INTO conseils_terrabot (id_categorie, theme, etat_constate, etat_plantation, titre, conseil, priorite) VALUES
(7,'irrigation',NULL,NULL,'Irrigation du grenadier','Plante rustique mais qui apprécie une irrigation régulière (environ toutes les 10 jours en été) pendant la fructification : les à-coups hydriques provoquent l''éclatement des fruits. Réduisez l''eau à l''approche de la maturité.',1),
(7,'entretien',NULL,NULL,'Drageons et taille','Supprimez régulièrement les drageons à la base, faites une taille d''éclaircie en hiver pour aérer le centre et apportez de la fumure organique.',2),
(7,'croissance',NULL,'En croissance','Floraison et fructification','La floraison a lieu au printemps et les fruits mûrissent à l''automne. Une fertilisation équilibrée soutient la nouaison.',2),
(7,'sante','Mauvais',NULL,'Ravageurs du grenadier','Surveillez le papillon du grenadier (fruits percés), les pucerons et les cochenilles. Ramassez et détruisez les fruits atteints ou momifiés pour limiter les foyers.',1),
(7,'recolte',NULL,'Prête à récolter','Récolte des grenades','Récoltez lorsque la peau a pris sa couleur et sonne légèrement métallique au tapotement, en coupant le fruit avec un sécateur.',2);
