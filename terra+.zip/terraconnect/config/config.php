<?php
/**
 * TerraConnect - Configuration
 * Modifiez ces valeurs selon votre serveur (XAMPP / WAMP / MAMP : root sans mot de passe par défaut).
 */
define('DB_HOST', getenv('TC_DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('TC_DB_NAME') ?: 'terraconnect');
define('DB_USER', getenv('TC_DB_USER') ?: 'root');
define('DB_PASS', getenv('TC_DB_PASS') !== false ? getenv('TC_DB_PASS') : '');
define('DB_CHARSET', 'utf8mb4');

define('UPLOAD_DIR', __DIR__ . '/../uploads/suivis/');
define('UPLOAD_URL', 'uploads/suivis/');
define('UPLOAD_MAX_BYTES', 3 * 1024 * 1024); // 3 Mo

date_default_timezone_set('Africa/Tunis');
