<?php
require_once __DIR__ . '/config.php';

/** Retourne une connexion PDO unique (requêtes préparées, exceptions activées). */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            if (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['erreur' => 'Connexion à la base de données impossible.']);
            } else {
                echo '<p style="font-family:sans-serif;padding:20px">Connexion à la base de données impossible. '
                   . 'Vérifiez <code>config/config.php</code> et importez <code>database/terraconnect.sql</code>.</p>';
            }
            exit;
        }
    }
    return $pdo;
}
