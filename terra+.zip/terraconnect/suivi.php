<?php
require_once __DIR__ . '/includes/functions.php';

$pdo = db();

/* ---------- Traitement des formulaires (POST) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $retour = 'suivi.php';
    if (!csrf_ok($_POST['csrf'] ?? null)) {
        flash('Session expirée, veuillez réessayer.', 'err');
        redirect($retour);
    }
    $action = $_POST['action'] ?? 'ajouter';

    if ($action === 'supprimer') {
        $idSuivi = (int)($_POST['id_suivi'] ?? 0);
        $st = $pdo->prepare('SELECT id_plantation, photo FROM suivis WHERE id_suivi = ?');
        $st->execute([$idSuivi]);
        if ($row = $st->fetch()) {
            $pdo->prepare('DELETE FROM suivis WHERE id_suivi = ?')->execute([$idSuivi]);
            supprimer_photo($row['photo']);
            flash('Intervention supprimée.');
            redirect('suivi.php?id=' . (int)$row['id_plantation']);
        }
        redirect($retour);
    }

    // Ajout d'un suivi
    $idP   = (int)($_POST['id_plantation'] ?? 0);
    $date  = trim($_POST['date_suivi'] ?? '');
    $type  = $_POST['type_intervention'] ?? '';
    $etat  = $_POST['etat_constate'] ?? '';
    $qte   = str_replace(',', '.', trim($_POST['quantite'] ?? ''));
    $unite = $_POST['unite'] ?? '';
    $desc  = trim($_POST['description'] ?? '');
    $retour = 'suivi.php?id=' . $idP;

    $err = [];
    if (!plantation_par_id($idP)) $err[] = 'Plantation introuvable.';
    if (!valid_date($date)) $err[] = 'Date invalide.';
    if (!in_array($type, TYPES_INTERVENTION, true)) $err[] = "Type d'intervention invalide.";
    if (!in_array($etat, ETATS_SANTE, true)) $err[] = 'État constaté invalide.';
    if ($qte !== '' && (!is_numeric($qte) || (float)$qte < 0 || (float)$qte > 1000000)) $err[] = 'Quantité invalide.';
    if ($unite !== '' && !in_array($unite, UNITES, true)) $err[] = 'Unité invalide.';
    if (mb_strlen($desc, 'UTF-8') > 300) $err[] = 'La description dépasse 300 caractères.';

    $photo = null;
    if (!$err) {
        [$photo, $errPhoto] = enregistrer_photo($_FILES['photo'] ?? []);
        if ($errPhoto) $err[] = $errPhoto;
    }
    if ($err) {
        foreach ($err as $e) flash($e, 'err');
        redirect($idP ? $retour : 'suivi.php');
    }

    $st = $pdo->prepare(
        'INSERT INTO suivis (id_plantation, date_suivi, type_intervention, etat_constate, quantite, unite, photo, description)
         VALUES (?,?,?,?,?,?,?,?)'
    );
    $st->execute([$idP, $date, $type, $etat, $qte === '' ? null : $qte, ($qte === '' || $unite === '') ? null : $unite, $photo, $desc === '' ? null : $desc]);
    flash('Suivi ajouté.');
    redirect($retour);
}

/* ---------- Données ---------- */
$plantations = $pdo->query(
    'SELECT p.id_plantation, c.nom AS culture, p.localisation
     FROM plantations p JOIN categories_plantes c ON c.id_categorie = p.id_categorie
     ORDER BY p.date_plantation DESC, p.id_plantation DESC'
)->fetchAll();

$idSel = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sel = $idSel ? plantation_par_id($idSel) : null;
if (!$sel && $plantations) {
    $sel = plantation_par_id((int)$plantations[0]['id_plantation']);
}

$suivis = [];
$sante = null;
if ($sel) {
    $st = $pdo->prepare('SELECT * FROM suivis WHERE id_plantation = ? ORDER BY date_suivi DESC, id_suivi DESC');
    $st->execute([$sel['id_plantation']]);
    $suivis = $st->fetchAll();
    $sante = $suivis ? $suivis[0]['etat_constate'] : null;
}

$titre = 'Suivi';
$actif = 'suivi';
require __DIR__ . '/includes/header.php';
?>
    <section class="entete">
        <h1>Suivi des plantations</h1>
        <p>Enregistrez les interventions (arrosage, fertilisation, traitement, récolte…), consultez l'historique de chaque plantation et demandez conseil à TerraBot.</p>
    </section>

    <?= flash_render() ?>

<?php if (!$plantations): ?>
    <section class="carte">
        <div class="vide"><i class="fa-solid fa-seedling"></i>
            Aucune plantation à suivre pour le moment.<br><br>
            <a class="btn" href="plantations.php#formulaire"><i class="fa-solid fa-plus"></i> Ajouter une plantation</a>
        </div>
    </section>
<?php else: ?>

    <!-- ===== Tableau de bord dynamique (rempli par assets/js/suivi.js) ===== -->
    <section class="stats" id="dash-stats" aria-label="Tableau de bord">
        <div class="stat"><div class="ico"><i class="fa-solid fa-seedling"></i></div><div><strong data-k="plantations">-</strong><span>Plantations suivies</span></div></div>
        <div class="stat"><div class="ico"><i class="fa-solid fa-list-check"></i></div><div><strong data-k="interventions">-</strong><span>Interventions</span></div></div>
        <div class="stat"><div class="ico"><i class="fa-solid fa-heart-pulse"></i></div><div><strong data-k="bon_etat">-</strong><span>En bon état</span></div></div>
        <div class="stat"><div class="ico"><i class="fa-solid fa-triangle-exclamation"></i></div><div><strong data-k="a_surveiller">-</strong><span>À surveiller</span></div></div>
    </section>

    <div class="grille-2">
        <section class="carte">
            <h2><i class="fa-solid fa-heart-pulse"></i> État de santé des plantations</h2>
            <div id="graph-sante" class="barres"><div class="vide">Chargement…</div></div>
        </section>
        <section class="carte">
            <h2><i class="fa-solid fa-chart-column"></i> Opérations agricoles</h2>
            <div id="graph-types" class="barres"><div class="vide">Chargement…</div></div>
        </section>
    </div>

    <section class="carte">
        <h2><i class="fa-solid fa-table-list"></i> Vue d'ensemble <small class="maj" id="maj"></small></h2>
        <table>
            <thead><tr><th>Plantation</th><th>État</th><th>Santé</th><th>Interventions</th><th>Dernier suivi</th><th>Avancement</th><th></th></tr></thead>
            <tbody id="vue-ensemble"><tr><td colspan="7" class="vide">Chargement…</td></tr></tbody>
        </table>
    </section>

    <!-- ===== Choix de la plantation ===== -->
    <nav class="onglets" aria-label="Choix de la plantation">
        <?php foreach ($plantations as $p): ?>
            <a href="suivi.php?id=<?= (int)$p['id_plantation'] ?>" class="<?= $sel && (int)$sel['id_plantation'] === (int)$p['id_plantation'] ? 'actif' : '' ?>"><?= h($p['culture']) ?> - <?= h($p['localisation']) ?></a>
        <?php endforeach; ?>
    </nav>

    <section class="carte">
        <h2><i class="fa-solid fa-plus"></i> Ajouter un suivi</h2>

        <form action="suivi.php" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="ajouter">

            <div class="form-group">
                <label for="id_plantation">Plantation</label>
                <select id="id_plantation" name="id_plantation" required>
                    <option value="">Choisir une plantation</option>
                    <?php foreach ($plantations as $p): ?>
                        <option value="<?= (int)$p['id_plantation'] ?>" <?= $sel && (int)$sel['id_plantation'] === (int)$p['id_plantation'] ? 'selected' : '' ?>><?= h($p['culture']) ?> - <?= h($p['localisation']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="date_suivi">Date</label>
                <input type="date" id="date_suivi" name="date_suivi" required value="<?= date('Y-m-d') ?>">
            </div>

            <div class="form-group">
                <label for="type_intervention">Type d'intervention</label>
                <select id="type_intervention" name="type_intervention" required>
                    <option value="">Choisir un type</option>
                    <?php foreach (TYPES_INTERVENTION as $t): ?><option><?= h($t) ?></option><?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="etat_constate">État constaté</label>
                <select id="etat_constate" name="etat_constate" required>
                    <option value="">Choisir</option>
                    <?php foreach (ETATS_SANTE as $e): ?><option><?= h($e) ?></option><?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="quantite">Quantité <small>(facultatif)</small></label>
                <input type="number" id="quantite" name="quantite" min="0" max="1000000" step="0.01" placeholder="Ex : 800">
            </div>

            <div class="form-group">
                <label for="unite">Unité</label>
                <select id="unite" name="unite">
                    <option value="">-</option>
                    <?php foreach (UNITES as $u): ?><option><?= h($u) ?></option><?php endforeach; ?>
                </select>
            </div>

            <div class="form-group full">
                <label for="photo">Photo <small>(facultatif - JPG, PNG, WebP, 3 Mo max)</small></label>
                <input type="file" id="photo" name="photo" accept="image/jpeg,image/png,image/webp,image/gif">
            </div>

            <div class="form-group full">
                <label for="description">Description</label>
                <textarea id="description" name="description" maxlength="300" placeholder="Détails de l'intervention (300 caractères max)"></textarea>
            </div>

            <div class="form-group full">
                <button type="submit"><i class="fa-solid fa-plus"></i> Ajouter le suivi</button>
            </div>
        </form>
    </section>

<?php if ($sel): $pct = avancement($sel); ?>
    <section class="carte" id="detail" data-id="<?= (int)$sel['id_plantation'] ?>">
        <h2><i class="fa-solid <?= h($sel['icone']) ?>"></i> <?= h($sel['culture']) ?> - <?= h($sel['localisation']) ?></h2>
        <div class="resume">
            <div><small>Culture</small><b><?= h($sel['culture']) ?></b></div>
            <div><small>Superficie</small><b><?= h(fmt_num($sel['superficie_ha'])) ?> ha</b></div>
            <div><small>Localisation</small><b><?= h($sel['localisation']) ?></b></div>
            <div><small>État</small><span class="tag <?= classe_etat($sel['etat']) ?>"><?= h($sel['etat']) ?></span></div>
            <div><small>Plantée le</small><b><?= h(fmt_date($sel['date_plantation'])) ?></b></div>
            <div><small>Récolte prévue</small><b><?= h(fmt_date($sel['date_recolte_prevue'])) ?></b></div>
            <div><small>Interventions</small><b><?= count($suivis) ?></b></div>
            <div><small>Avancement</small><b><?= $pct ?> %</b></div>
            <div><small>État de santé</small><span class="tag <?= classe_sante($sante) ?>"><?= h($sante ?? 'Non évalué') ?></span></div>
            <div><small>Dernier suivi</small><b><?= $suivis ? h(fmt_date($suivis[0]['date_suivi'])) : '-' ?></b></div>
            <div><small>Type de culture</small><b><?= h($sel['type_culture']) ?></b></div>
            <div><small>Arrosage conseillé</small><b>tous les <?= (int)$sel['frequence_arrosage_jours'] ?> j</b></div>
        </div>
        <h3 style="margin-top:18px">Évolution de l'état de santé</h3>
        <div id="courbe-sante" class="courbe"></div>
    </section>

    <div class="grille-suivi">
        <section class="carte">
            <h2><i class="fa-solid fa-clock-rotate-left"></i> Historique du suivi</h2>
            <?php if (!$suivis): ?>
                <div class="vide"><i class="fa-solid fa-clipboard-list"></i>Aucune intervention enregistrée pour cette plantation.</div>
            <?php else: ?>
            <ul class="timeline">
                <?php foreach ($suivis as $s): ?>
                <li>
                    <div class="pt"><i class="fa-solid <?= icone_intervention($s['type_intervention']) ?>"></i></div>
                    <div class="corps">
                        <div class="haut"><strong><?= h($s['type_intervention']) ?></strong><span class="date"><?= h(fmt_date($s['date_suivi'])) ?></span></div>
                        <?php if ($s['description']): ?><p><?= h($s['description']) ?></p><?php endif; ?>
                        <?php if ($s['photo'] && preg_match('/^[a-f0-9]{32}\.(jpg|png|webp|gif)$/', $s['photo'])): ?>
                            <a href="<?= h(UPLOAD_URL . $s['photo']) ?>" target="_blank" rel="noopener"><img class="vignette" src="<?= h(UPLOAD_URL . $s['photo']) ?>" alt="Photo du suivi" loading="lazy"></a>
                        <?php endif; ?>
                        <div class="meta">
                            <span class="tag <?= classe_sante($s['etat_constate']) ?>"><?= h($s['etat_constate']) ?></span>
                            <?php if ($s['quantite'] !== null): ?><span><i class="fa-solid fa-scale-balanced"></i> <?= h(fmt_num($s['quantite'])) ?> <?= h($s['unite']) ?></span><?php endif; ?>
                            <form action="suivi.php" method="post" class="form-suppr" data-nom="<?= h($s['type_intervention'] . ' du ' . fmt_date($s['date_suivi'])) ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="supprimer">
                                <input type="hidden" name="id_suivi" value="<?= (int)$s['id_suivi'] ?>">
                                <button type="submit" class="petit danger" title="Supprimer"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </section>

        <!-- ===== TerraBot ===== -->
        <section class="carte terrabot" id="terrabot" aria-label="Assistant agricole TerraBot">
            <h2><i class="fa-solid fa-robot"></i> TerraBot <small>assistant agricole</small></h2>
            <div class="form-group">
                <label for="tb-plantation">Plantation concernée</label>
                <select id="tb-plantation">
                    <?php foreach ($plantations as $p): ?>
                        <option value="<?= (int)$p['id_plantation'] ?>" <?= (int)$sel['id_plantation'] === (int)$p['id_plantation'] ? 'selected' : '' ?>><?= h($p['culture']) ?> - <?= h($p['localisation']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="tb-actions">
                <button type="button" class="petit secondaire" data-theme="general"><i class="fa-solid fa-stethoscope"></i> Diagnostic</button>
                <button type="button" class="petit secondaire" data-theme="irrigation"><i class="fa-solid fa-droplet"></i> Irrigation</button>
                <button type="button" class="petit secondaire" data-theme="entretien"><i class="fa-solid fa-screwdriver-wrench"></i> Entretien</button>
                <button type="button" class="petit secondaire" data-theme="croissance"><i class="fa-solid fa-arrow-trend-up"></i> Croissance</button>
            </div>
            <div class="tb-log" id="tb-log" aria-live="polite">
                <div class="tb-msg bot"><p>Bonjour, je suis TerraBot. Choisissez une plantation puis un thème, ou posez-moi une question (arrosage, taille, jaunissement des feuilles…).</p></div>
            </div>
            <div class="tb-saisie">
                <input type="text" id="tb-question" maxlength="300" placeholder="Posez votre question à TerraBot…" aria-label="Question pour TerraBot">
                <button type="button" id="tb-envoyer"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
            <p class="aide" style="margin-top:8px">Les conseils sont indicatifs : adaptez-les à votre sol, votre climat et l'avis d'un technicien agricole.</p>
        </section>
    </div>
<?php endif; ?>
<?php endif; ?>

<script src="assets/js/suivi.js"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
