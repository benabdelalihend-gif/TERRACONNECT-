# TerraConnect - Plantations et Suivi (PHP / MySQL)

Version dynamique du projet : pages **Plantations** et **Suivi**, assistant **TerraBot** et base de données MySQL.

## Installation (XAMPP / WAMP / MAMP)
1. Copier le dossier `terraconnect` dans `htdocs` (ou `www`).
2. Démarrer Apache et MySQL.
3. Importer `database/terraconnect.sql` (phpMyAdmin > Importer, ou `mysql -u root -p < database/terraconnect.sql`).
   Le script crée la base `terraconnect`, les tables et les données initiales.
4. Vérifier `config/config.php` (hôte, utilisateur, mot de passe).
5. Ouvrir `http://localhost/terraconnect/`.

Prérequis : PHP 7.4+ (extensions PDO MySQL, fileinfo, mbstring), MySQL 8 ou MariaDB 10.2+.
Le dossier `uploads/suivis/` doit être accessible en écriture (photos des suivis).

## Contenu
- `plantations.php` : ajout, modification, suppression, recherche et filtre par culture. Cultures : Olivier, Tomate, Blé, Vigne, **Amandier, Citronnier, Grenadier**.
- `suivi.php` : tableau de bord dynamique (statistiques, santé, opérations, vue d'ensemble, courbe d'évolution), ajout de suivi avec photo, historique, **TerraBot**.
- `api/dashboard.php` : données du tableau de bord (actualisé toutes les 30 s).
- `api/terrabot.php` : réponses de TerraBot (irrigation, entretien, croissance, diagnostic ou question libre).
- `includes/terrabot.php` : logique de TerraBot.
- `database/terraconnect.sql` : base de données complète.
- `ancienne_version_html/` : les pages HTML d'origine, conservées pour référence.

## Base de données
| Table | Rôle |
|---|---|
| `categories_plantes` | Catégories (nom, type, durée du cycle, fréquence d'arrosage conseillée, saisons) |
| `plantations` | Plantations (catégorie, superficie, dates, localisation, état) |
| `suivis` | Historique des opérations et état de santé constaté (+ photo) |
| `conseils_terrabot` | Base de conseils par catégorie, thème, état de santé et état de la plantation |
| `terrabot_messages` | Historique des échanges avec TerraBot |
| `v_plantations_sante` (vue) | Plantation + dernier état de santé + nombre d'interventions |

Toute plantation ajoutée apparaît automatiquement dans la page Suivi (mêmes données en base).
La suppression d'une plantation supprime son historique (clé étrangère en cascade).

## TerraBot
Les conseils proviennent de la table `conseils_terrabot` et sont complétés par des alertes calculées
(arrosage en retard selon la catégorie, absence de suivi récent, état « Mauvais », récolte proche).
Pour ajouter des conseils, insérez simplement des lignes dans `conseils_terrabot`.
Les conseils sont indicatifs et à adapter au terrain et à l'avis d'un technicien agricole.

## Sécurité
Requêtes préparées (PDO), échappement HTML, jeton CSRF, validation côté serveur, contrôle du type réel des photos.
