<?php
header('Location: plantations.php');
exit;
