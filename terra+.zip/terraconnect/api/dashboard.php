<?php
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$pdo = db();

$plantations = $pdo->query(
    'SELECT v.*, c.duree_cycle_jours
     FROM v_plantations_sante v JOIN categories_plantes c ON c.id_categorie = v.id_categorie
     ORDER BY v.date_plantation DESC, v.id_plantation DESC'
)->fetchAll();

$score = ['Mauvais' => 1, 'Moyen' => 2, 'Bon' => 3];
$sante = ['Bon' => 0, 'Moyen' => 0, 'Mauvais' => 0, 'Non évalué' => 0];
$liste = [];
foreach ($plantations as $p) {
    $s = $p['sante'] ?: 'Non évalué';
    $sante[$s]++;

    $st = $pdo->prepare('SELECT date_suivi, etat_constate FROM suivis WHERE id_plantation = ? ORDER BY date_suivi DESC, id_suivi DESC LIMIT 8');
    $st->execute([$p['id_plantation']]);
    $hist = array_reverse($st->fetchAll());
    $courbe = array_map(function ($r) use ($score) { return ['date' => fmt_date($r['date_suivi']), 'score' => $score[$r['etat_constate']]]; }, $hist);

    $liste[] = [
        'id'          => (int)$p['id_plantation'],
        'culture'     => $p['culture'],
        'icone'       => $p['icone'],
        'localisation'=> $p['localisation'],
        'superficie'  => fmt_num($p['superficie_ha']),
        'etat'        => $p['etat'],
        'classe_etat' => classe_etat($p['etat']),
        'sante'       => $s,
        'classe_sante'=> classe_sante($p['sante']),
        'dernier_suivi' => $p['dernier_suivi'] ? fmt_date($p['dernier_suivi']) : '-',
        'interventions' => (int)$p['nb_interventions'],
        'avancement'  => avancement($p),
        'courbe'      => $courbe,
    ];
}

$types = array_fill_keys(TYPES_INTERVENTION, 0);
foreach ($pdo->query('SELECT type_intervention, COUNT(*) n FROM suivis GROUP BY type_intervention') as $r) {
    $types[$r['type_intervention']] = (int)$r['n'];
}

$recent = [];
$q = $pdo->query(
    'SELECT s.date_suivi, s.type_intervention, s.etat_constate, s.description, c.nom AS culture, p.localisation
     FROM suivis s JOIN plantations p ON p.id_plantation = s.id_plantation
     JOIN categories_plantes c ON c.id_categorie = p.id_categorie
     ORDER BY s.date_suivi DESC, s.id_suivi DESC LIMIT 5'
);
foreach ($q as $r) {
    $recent[] = [
        'date' => fmt_date($r['date_suivi']), 'type' => $r['type_intervention'], 'icone' => icone_intervention($r['type_intervention']),
        'sante' => $r['etat_constate'], 'classe_sante' => classe_sante($r['etat_constate']),
        'plantation' => $r['culture'] . ' - ' . $r['localisation'], 'description' => $r['description'],
    ];
}

echo json_encode([
    'totaux' => [
        'plantations'   => count($plantations),
        'interventions' => array_sum($types),
        'bon_etat'      => $sante['Bon'],
        'a_surveiller'  => $sante['Moyen'] + $sante['Mauvais'],
    ],
    'sante'        => $sante,
    'interventions'=> $types,
    'plantations'  => $liste,
    'recentes'     => $recent,
    'maj'          => date('H:i:s'),
], JSON_UNESCAPED_UNICODE);
