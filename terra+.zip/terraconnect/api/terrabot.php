<?php
require_once __DIR__ . '/../includes/terrabot.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['erreur' => 'Méthode non autorisée.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) $data = $_POST;

if (!csrf_ok($data['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null))) {
    http_response_code(403);
    echo json_encode(['erreur' => 'Session expirée, rechargez la page.']);
    exit;
}

$id = (int)($data['id_plantation'] ?? 0);
$theme = (string)($data['theme'] ?? 'general');
$question = trim((string)($data['question'] ?? ''));
if (mb_strlen($question, 'UTF-8') > 300) $question = mb_substr($question, 0, 300, 'UTF-8');

$rep = terrabot_repondre($id, $theme, $question);
if ($rep === null) {
    http_response_code(404);
    echo json_encode(['erreur' => 'Plantation introuvable.']);
    exit;
}
echo json_encode($rep, JSON_UNESCAPED_UNICODE);
