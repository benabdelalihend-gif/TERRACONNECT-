<?php
require_once __DIR__ . '/includes/functions.php';

$pdo = db();
$cats = categories();
$catParId = [];
foreach ($cats as $c) $catParId[(int)$c['id_categorie']] = $c;

/* ---------- Traitement des formulaires (POST) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok($_POST['csrf'] ?? null)) {
        flash('Session expirée, veuillez réessayer.', 'err');
        redirect('plantations.php');
    }
    $action = $_POST['action'] ?? 'ajouter';

    if ($action === 'supprimer') {
        $id = (int)($_POST['id_plantation'] ?? 0);
        $st = $pdo->prepare('SELECT photo FROM suivis WHERE id_plantation = ? AND photo IS NOT NULL');
        $st->execute([$id]);
        $photos = $st->fetchAll(PDO::FETCH_COLUMN);
        $del = $pdo->prepare('DELETE FROM plantations WHERE id_plantation = ?');
        $del->execute([$id]);
        if ($del->rowCount() > 0) {
            foreach ($photos as $p) supprimer_photo($p);
            flash('Plantation supprimée (ainsi que son historique de suivi).');
        }
        redirect('plantations.php');
    }

    // Ajout / modification
    $id    = (int)($_POST['id_plantation'] ?? 0);
    $idCat = (int)($_POST['id_culture'] ?? 0);
    $sup   = str_replace(',', '.', trim($_POST['superficie_ha'] ?? ''));
    $dPl   = trim($_POST['date_plantation'] ?? '');
    $dRec  = trim($_POST['date_recolte_prevue'] ?? '');
    $loc   = trim($_POST['localisation'] ?? '');
    $etat  = $_POST['etat'] ?? '';

    $err = [];
    if (!isset($catParId[$idCat])) $err[] = 'Culture invalide.';
    if (!is_numeric($sup) || (float)$sup < 0.01 || (float)$sup > 10000) $err[] = 'La superficie doit être comprise entre 0,01 et 10 000 ha.';
    if (!valid_date($dPl)) $err[] = 'Date de plantation invalide.';
    if ($dRec !== '' && !valid_date($dRec)) $err[] = 'Date de récolte invalide.';
    if ($dRec !== '' && valid_date($dPl) && valid_date($dRec) && $dRec < $dPl) $err[] = 'La récolte prévue ne peut pas précéder la plantation.';
    if (!preg_match("/^[\p{L}0-9 '\-]{2,100}$/u", $loc)) $err[] = 'Localisation invalide (2 à 100 caractères : lettres, chiffres, espaces, apostrophes, tirets).';
    if (!in_array($etat, ETATS_PLANTATION, true)) $err[] = 'État de la plantation invalide.';

    if ($err) {
        foreach ($err as $e) flash($e, 'err');
        redirect($id ? 'plantations.php?edit=' . $id : 'plantations.php');
    }

    if ($dRec === '') {
        $dRec = date_recolte_defaut($dPl, (int)$catParId[$idCat]['duree_cycle_jours']);
    }

    if ($action === 'modifier' && $id > 0) {
        $st = $pdo->prepare('UPDATE plantations SET id_categorie=?, superficie_ha=?, date_plantation=?, date_recolte_prevue=?, localisation=?, etat=? WHERE id_plantation=?');
        $st->execute([$idCat, $sup, $dPl, $dRec, $loc, $etat, $id]);
        flash('Plantation modifiée.');
    } else {
        $st = $pdo->prepare('INSERT INTO plantations (id_categorie, superficie_ha, date_plantation, date_recolte_prevue, localisation, etat) VALUES (?,?,?,?,?,?)');
        $st->execute([$idCat, $sup, $dPl, $dRec, $loc, $etat]);
        flash('Plantation ajoutée. Elle apparaît maintenant dans la page Suivi.');
    }
    redirect('plantations.php');
}

/* ---------- Données ---------- */
$edit = null;
if (isset($_GET['edit'])) {
    $edit = plantation_par_id((int)$_GET['edit']);
}

$liste = $pdo->query(
    'SELECT p.*, c.nom AS culture, c.icone, c.duree_cycle_jours
     FROM plantations p JOIN categories_plantes c ON c.id_categorie = p.id_categorie
     ORDER BY p.date_plantation DESC, p.id_plantation DESC'
)->fetchAll();

$nb = count($liste);
$totalHa = 0; $nbCrois = 0; $nbRecolte = 0;
foreach ($liste as $p) {
    $totalHa += (float)$p['superficie_ha'];
    if ($p['etat'] === 'En croissance') $nbCrois++;
    if ($p['etat'] === 'Prête à récolter') $nbRecolte++;
}

$titre = 'Plantations';
$actif = 'plantations';
require __DIR__ . '/includes/header.php';

// Valeurs du formulaire
$v = [
    'id_culture' => $edit['id_categorie'] ?? '',
    'superficie' => isset($edit['superficie_ha']) ? rtrim(rtrim($edit['superficie_ha'], '0'), '.') : '',
    'date_pl'    => $edit['date_plantation'] ?? '',
    'date_rec'   => $edit['date_recolte_prevue'] ?? '',
    'loc'        => $edit['localisation'] ?? '',
    'etat'       => $edit['etat'] ?? '',
];
?>
    <section class="entete">
        <h1>Gestion des plantations</h1>
        <p>Ajoutez vos cultures, suivez leur avancement et accédez au suivi détaillé de chaque plantation.</p>
    </section>

    <?= flash_render() ?>

    <section class="stats" aria-label="Statistiques">
        <div class="stat"><div class="ico"><i class="fa-solid fa-seedling"></i></div><div><strong><?= $nb ?></strong><span>Plantations</span></div></div>
        <div class="stat"><div class="ico"><i class="fa-solid fa-ruler-combined"></i></div><div><strong><?= h(fmt_num($totalHa)) ?> ha</strong><span>Superficie totale</span></div></div>
        <div class="stat"><div class="ico"><i class="fa-solid fa-arrow-trend-up"></i></div><div><strong><?= $nbCrois ?></strong><span>En croissance</span></div></div>
        <div class="stat"><div class="ico"><i class="fa-solid fa-basket-shopping"></i></div><div><strong><?= $nbRecolte ?></strong><span>Prêtes à récolter</span></div></div>
    </section>

    <section class="carte" id="formulaire">
        <h2><i class="fa-solid fa-<?= $edit ? 'pen' : 'plus' ?>"></i> <?= $edit ? 'Modifier la plantation' : 'Ajouter une plantation' ?></h2>

        <form action="plantations.php" method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="<?= $edit ? 'modifier' : 'ajouter' ?>">
            <?php if ($edit): ?><input type="hidden" name="id_plantation" value="<?= (int)$edit['id_plantation'] ?>"><?php endif; ?>

            <div class="form-group">
                <label for="id_culture">Culture</label>
                <select id="id_culture" name="id_culture" required>
                    <option value="">Choisir une culture</option>
                    <?php foreach ($cats as $c): ?>
                        <option value="<?= (int)$c['id_categorie'] ?>" data-cycle="<?= (int)$c['duree_cycle_jours'] ?>" <?= (string)$v['id_culture'] === (string)$c['id_categorie'] ? 'selected' : '' ?>><?= h($c['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="superficie_ha">Superficie (hectares)</label>
                <input type="number" id="superficie_ha" name="superficie_ha" min="0.01" max="10000" step="0.01" required placeholder="Ex : 2" value="<?= h($v['superficie']) ?>">
            </div>

            <div class="form-group">
                <label for="date_plantation">Date de plantation</label>
                <input type="date" id="date_plantation" name="date_plantation" required value="<?= h($v['date_pl']) ?>">
            </div>

            <div class="form-group">
                <label for="date_recolte_prevue">Date de récolte prévue <small>(facultatif)</small></label>
                <input type="date" id="date_recolte_prevue" name="date_recolte_prevue" value="<?= h($v['date_rec']) ?>">
                <span class="aide">Si vide, elle est calculée selon la durée du cycle de la culture.</span>
            </div>

            <div class="form-group">
                <label for="localisation">Localisation</label>
                <input type="text" id="localisation" name="localisation" required minlength="2" maxlength="100"
                       pattern="[A-Za-zÀ-ÖØ-öø-ÿ0-9 '\-]{2,100}"
                       title="2 à 100 caractères : lettres, chiffres, espaces, apostrophes et tirets." placeholder="Ex : Ariana" value="<?= h($v['loc']) ?>">
            </div>

            <div class="form-group">
                <label for="etat">État de la plantation</label>
                <select id="etat" name="etat" required>
                    <option value="">Choisir un état</option>
                    <?php foreach (ETATS_PLANTATION as $e): ?>
                        <option <?= $v['etat'] === $e ? 'selected' : '' ?>><?= h($e) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group full">
                <div class="btn-ligne">
                    <button type="submit"><i class="fa-solid fa-<?= $edit ? 'floppy-disk' : 'plus' ?>"></i> <?= $edit ? 'Enregistrer les modifications' : 'Ajouter la plantation' ?></button>
                    <?php if ($edit): ?>
                        <a class="btn secondaire" href="plantations.php">Annuler</a>
                    <?php else: ?>
                        <button type="reset" class="secondaire">Réinitialiser</button>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </section>

    <section class="carte">
        <h2><i class="fa-solid fa-list"></i> Mes plantations</h2>

        <div class="outils">
            <div class="champ"><i class="fa-solid fa-magnifying-glass"></i>
                <input type="search" id="recherche" placeholder="Rechercher (culture, localisation…)" aria-label="Rechercher">
            </div>
            <select id="filtre-culture" aria-label="Filtrer par culture">
                <option value="">Toutes les cultures</option>
                <?php foreach ($cats as $c): ?>
                    <option><?= h($c['nom']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <?php if (!$liste): ?>
            <div class="vide"><i class="fa-solid fa-seedling"></i>Aucune plantation pour le moment. Ajoutez-en une avec le formulaire ci-dessus.</div>
        <?php else: ?>
        <table id="table-plantations">
            <thead>
                <tr>
                    <th>Culture</th>
                    <th>Superficie</th>
                    <th>Date</th>
                    <th>Localisation</th>
                    <th>État</th>
                    <th>Avancement</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($liste as $p): $pct = avancement($p); ?>
            <tr data-culture="<?= h($p['culture']) ?>">
                <td><i class="fa-solid <?= h($p['icone']) ?>" style="color:var(--vert-clair)"></i> <strong><?= h($p['culture']) ?></strong></td>
                <td><?= h(fmt_num($p['superficie_ha'])) ?> ha</td>
                <td><?= h(fmt_date($p['date_plantation'])) ?></td>
                <td><?= h($p['localisation']) ?></td>
                <td><span class="tag <?= classe_etat($p['etat']) ?>"><?= h($p['etat']) ?></span></td>
                <td><span class="progress"><i style="width:<?= $pct ?>%"></i></span><span class="progress-txt"><?= $pct ?>%</span></td>
                <td><div class="actions">
                    <a class="btn petit" href="suivi.php?id=<?= (int)$p['id_plantation'] ?>"><i class="fa-solid fa-clipboard-list"></i> Suivi</a>
                    <a class="btn petit secondaire" href="plantations.php?edit=<?= (int)$p['id_plantation'] ?>#formulaire"><i class="fa-solid fa-pen"></i> Modifier</a>
                    <form action="plantations.php" method="post" class="form-suppr" data-nom="<?= h($p['culture'] . ' - ' . $p['localisation']) ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="supprimer">
                        <input type="hidden" name="id_plantation" value="<?= (int)$p['id_plantation'] ?>">
                        <button type="submit" class="petit danger"><i class="fa-solid fa-trash"></i> Supprimer</button>
                    </form>
                </div></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p class="vide" id="aucun-resultat" hidden>Aucune plantation ne correspond à votre recherche.</p>
        <?php endif; ?>
    </section>

<script src="assets/js/plantations.js"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
