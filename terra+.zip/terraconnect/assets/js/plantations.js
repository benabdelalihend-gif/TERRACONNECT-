// Page Plantations : filtre/recherche, confirmation de suppression, date de récolte suggérée
(function () {
  'use strict';

  var recherche = document.getElementById('recherche');
  var filtre = document.getElementById('filtre-culture');
  var table = document.getElementById('table-plantations');
  var aucun = document.getElementById('aucun-resultat');

  function filtrer() {
    if (!table) return;
    var q = (recherche.value || '').toLowerCase().trim();
    var c = filtre.value;
    var visibles = 0;
    table.querySelectorAll('tbody tr').forEach(function (tr) {
      var ok = (!c || tr.dataset.culture === c) && (!q || tr.textContent.toLowerCase().indexOf(q) !== -1);
      tr.hidden = !ok;
      if (ok) visibles++;
    });
    if (aucun) aucun.hidden = visibles !== 0;
  }
  if (recherche) recherche.addEventListener('input', filtrer);
  if (filtre) filtre.addEventListener('change', filtrer);

  document.querySelectorAll('.form-suppr').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      var nom = f.dataset.nom || 'cette plantation';
      if (!confirm('Supprimer la plantation « ' + nom + ' » et tout son historique de suivi ?')) e.preventDefault();
    });
  });

  // Suggestion de la date de récolte selon la durée du cycle de la culture
  var cult = document.getElementById('id_culture');
  var dPl = document.getElementById('date_plantation');
  var dRec = document.getElementById('date_recolte_prevue');
  var modifieeAMain = !!(dRec && dRec.value);
  if (dRec) dRec.addEventListener('input', function () { modifieeAMain = true; });

  function suggerer() {
    if (!cult || !dPl || !dRec || modifieeAMain || !dPl.value) return;
    var opt = cult.options[cult.selectedIndex];
    var cycle = opt ? parseInt(opt.dataset.cycle, 10) : 0;
    if (!cycle) return;
    var d = new Date(dPl.value + 'T00:00:00');
    d.setDate(d.getDate() + cycle);
    dRec.value = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  if (cult) cult.addEventListener('change', suggerer);
  if (dPl) dPl.addEventListener('change', suggerer);
})();
