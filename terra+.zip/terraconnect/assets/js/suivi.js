// Page Suivi : tableau de bord dynamique + assistant TerraBot
(function () {
  'use strict';

  var csrf = (document.querySelector('meta[name="csrf"]') || {}).content || '';

  function el(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt !== undefined && txt !== null) e.textContent = txt;
    return e;
  }

  /* ---------- Confirmation de suppression ---------- */
  document.querySelectorAll('.form-suppr').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (!confirm('Supprimer « ' + (f.dataset.nom || 'cette intervention') + ' » ?')) e.preventDefault();
    });
  });

  /* ---------- Tableau de bord ---------- */
  var dash = document.getElementById('dash-stats');
  if (dash) {
    var detail = document.getElementById('detail');
    var idDetail = detail ? parseInt(detail.dataset.id, 10) : 0;

    var barres = function (conteneur, lignes) {
      conteneur.textContent = '';
      var max = Math.max.apply(null, lignes.map(function (l) { return l.n; }).concat([1]));
      lignes.forEach(function (l) {
        var row = el('div', 'barre-ligne');
        row.appendChild(el('span', 'barre-label', l.label));
        var piste = el('span', 'barre-piste');
        var rempl = el('i', 'barre-rempl ' + (l.classe || ''));
        rempl.style.width = (l.n / max * 100) + '%';
        piste.appendChild(rempl);
        row.appendChild(piste);
        row.appendChild(el('span', 'barre-val', String(l.n)));
        conteneur.appendChild(row);
      });
    };

    var courbe = function (conteneur, points) {
      conteneur.textContent = '';
      if (!points.length) { conteneur.appendChild(el('p', 'vide', 'Aucun suivi enregistré.')); return; }
      var NS = 'http://www.w3.org/2000/svg', W = 560, H = 150, mx = 70, my = 22;
      var svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
      svg.setAttribute('role', 'img');
      svg.setAttribute('aria-label', "Évolution de l'état de santé");
      var niveaux = [[3, 'Bon'], [2, 'Moyen'], [1, 'Mauvais']];
      var y = function (s) { return my + (3 - s) * ((H - 2 * my) / 2); };
      niveaux.forEach(function (n) {
        var l = document.createElementNS(NS, 'line');
        l.setAttribute('x1', mx); l.setAttribute('x2', W - 15); l.setAttribute('y1', y(n[0])); l.setAttribute('y2', y(n[0]));
        l.setAttribute('stroke', '#dfe8d9'); svg.appendChild(l);
        var t = document.createElementNS(NS, 'text');
        t.setAttribute('x', 8); t.setAttribute('y', y(n[0]) + 4); t.setAttribute('font-size', '12'); t.setAttribute('fill', '#607568');
        t.textContent = n[1]; svg.appendChild(t);
      });
      var step = points.length > 1 ? (W - 15 - mx - 10) / (points.length - 1) : 0;
      var xs = points.map(function (p, i) { return points.length > 1 ? mx + 5 + i * step : (W + mx) / 2; });
      if (points.length > 1) {
        var poly = document.createElementNS(NS, 'polyline');
        poly.setAttribute('points', points.map(function (p, i) { return xs[i] + ',' + y(p.score); }).join(' '));
        poly.setAttribute('fill', 'none'); poly.setAttribute('stroke', '#8BBF65'); poly.setAttribute('stroke-width', '3');
        svg.appendChild(poly);
      }
      var couleurs = { 3: '#276749', 2: '#c98a00', 1: '#c0392b' };
      points.forEach(function (p, i) {
        var c = document.createElementNS(NS, 'circle');
        c.setAttribute('cx', xs[i]); c.setAttribute('cy', y(p.score)); c.setAttribute('r', 6); c.setAttribute('fill', couleurs[p.score]);
        var tt = document.createElementNS(NS, 'title'); tt.textContent = p.date; c.appendChild(tt);
        svg.appendChild(c);
        var d = document.createElementNS(NS, 'text');
        d.setAttribute('x', xs[i]); d.setAttribute('y', H - 4); d.setAttribute('font-size', '10'); d.setAttribute('text-anchor', 'middle'); d.setAttribute('fill', '#607568');
        d.textContent = p.date.slice(0, 5); svg.appendChild(d);
      });
      conteneur.appendChild(svg);
    };

    var rendre = function (d) {
      Object.keys(d.totaux).forEach(function (k) {
        var n = dash.querySelector('[data-k="' + k + '"]');
        if (n) n.textContent = d.totaux[k];
      });

      barres(document.getElementById('graph-sante'), [
        { label: 'Bon', n: d.sante['Bon'], classe: 'bon' },
        { label: 'Moyen', n: d.sante['Moyen'], classe: 'moyen' },
        { label: 'Mauvais', n: d.sante['Mauvais'], classe: 'mauvais' },
        { label: 'Non évalué', n: d.sante['Non évalué'], classe: 'neutre' }
      ]);
      barres(document.getElementById('graph-types'), Object.keys(d.interventions).map(function (k) {
        return { label: k, n: d.interventions[k], classe: 'neutre' };
      }));

      var tb = document.getElementById('vue-ensemble');
      tb.textContent = '';
      d.plantations.forEach(function (p) {
        var tr = document.createElement('tr');
        var td = el('td');
        var ic = el('i', 'fa-solid ' + p.icone); ic.style.color = 'var(--vert-clair)';
        td.appendChild(ic); td.appendChild(document.createTextNode(' '));
        td.appendChild(el('strong', null, p.culture + ' - ' + p.localisation));
        tr.appendChild(td);
        var t2 = el('td'); t2.appendChild(el('span', 'tag ' + p.classe_etat, p.etat)); tr.appendChild(t2);
        var t3 = el('td'); t3.appendChild(el('span', 'tag ' + p.classe_sante, p.sante)); tr.appendChild(t3);
        tr.appendChild(el('td', null, String(p.interventions)));
        tr.appendChild(el('td', null, p.dernier_suivi));
        var t6 = el('td');
        var pr = el('span', 'progress'); var bi = document.createElement('i'); bi.style.width = p.avancement + '%'; pr.appendChild(bi);
        t6.appendChild(pr); t6.appendChild(el('span', 'progress-txt', p.avancement + '%')); tr.appendChild(t6);
        var t7 = el('td'); var a = el('a', 'btn petit secondaire', 'Voir'); a.href = 'suivi.php?id=' + p.id; t7.appendChild(a); tr.appendChild(t7);
        tb.appendChild(tr);
      });

      var maj = document.getElementById('maj');
      if (maj) maj.textContent = 'mis à jour à ' + d.maj;

      var cc = document.getElementById('courbe-sante');
      if (cc && idDetail) {
        var cur = d.plantations.filter(function (p) { return p.id === idDetail; })[0];
        courbe(cc, cur ? cur.courbe : []);
      }
    };

    var charger = function () {
      fetch('api/dashboard.php', { headers: { 'Accept': 'application/json' }, cache: 'no-store' })
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(rendre)
        .catch(function () {
          var m = document.getElementById('maj');
          if (m) m.textContent = '(actualisation impossible)';
        });
    };
    charger();
    setInterval(charger, 30000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) charger(); });
  }

  /* ---------- TerraBot ---------- */
  var log = document.getElementById('tb-log');
  if (log) {
    var selPl = document.getElementById('tb-plantation');
    var champ = document.getElementById('tb-question');
    var envoyer = document.getElementById('tb-envoyer');
    var libelles = { general: 'Diagnostic général', irrigation: 'Conseils irrigation', entretien: 'Conseils entretien', croissance: 'Conseils croissance' };

    var ajouterMsg = function (cls) {
      var m = el('div', 'tb-msg ' + cls);
      log.appendChild(m);
      log.scrollTop = log.scrollHeight;
      return m;
    };

    var afficherReponse = function (r) {
      var m = ajouterMsg('bot');
      m.appendChild(el('p', null, r.message));
      r.alertes.forEach(function (a) {
        var b = el('div', 'tb-alerte ' + a.niveau);
        var ic = el('i', 'fa-solid fa-triangle-exclamation'); b.appendChild(ic);
        var c = el('div'); c.appendChild(el('strong', null, a.titre)); c.appendChild(el('p', null, a.texte)); b.appendChild(c);
        m.appendChild(b);
      });
      r.conseils.forEach(function (c) {
        var b = el('div', 'tb-conseil');
        b.appendChild(el('strong', null, c.titre));
        b.appendChild(el('p', null, c.conseil));
        m.appendChild(b);
      });
      log.scrollTop = log.scrollHeight;
    };

    var demander = function (theme, question) {
      var idP = parseInt(selPl.value, 10);
      if (!idP) return;
      ajouterMsg('user').appendChild(el('p', null, question || libelles[theme] || theme));
      var attente = ajouterMsg('bot'); attente.appendChild(el('p', null, 'TerraBot analyse la plantation…'));
      envoyer.disabled = true;
      fetch('api/terrabot.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': csrf },
        body: JSON.stringify({ id_plantation: idP, theme: theme, question: question || '', csrf: csrf })
      })
        .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.erreur || 'Erreur'); return j; }); })
        .then(function (j) { attente.remove(); afficherReponse(j); })
        .catch(function (e) { attente.textContent = ''; attente.appendChild(el('p', null, 'Désolé, je n\'ai pas pu répondre : ' + e.message)); })
        .then(function () { envoyer.disabled = false; });
    };

    document.querySelectorAll('.tb-actions button').forEach(function (b) {
      b.addEventListener('click', function () { demander(b.dataset.theme, ''); });
    });
    var envoyerQuestion = function () {
      var q = champ.value.trim();
      if (!q) return;
      champ.value = '';
      demander('general', q);
    };
    envoyer.addEventListener('click', envoyerQuestion);
    champ.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); envoyerQuestion(); } });
  }
})();
