<?php
$hosts = ['127.0.0.1', 'localhost'];
$ports = [3306, 3307];
$dbname = 'terraconnect';
$username = 'root';
$password = '';

$pdo = null;
$lastError = '';

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_TIMEOUT => 3,
];

foreach ($hosts as $host) {
    foreach ($ports as $port) {
        try {
            // 1. Connexion au serveur MySQL XAMPP (sans exiger que la base existe déjà)
            $serverPdo = new PDO(
                "mysql:host=$host;port=$port;charset=utf8mb4",
                $username,
                $password,
                $options
            );

            // 2. Vérifier si la base 'terraconnect' existe, sinon la créer et importer database.sql automatiquement
            $stmtDb = $serverPdo->query("SHOW DATABASES LIKE " . $serverPdo->quote($dbname));
            $dbExists = $stmtDb->fetch() !== false;

            if (!$dbExists) {
                $sqlFile = dirname(__DIR__) . '/database.sql';
                if (file_exists($sqlFile)) {
                    $sql = file_get_contents($sqlFile);
                    $serverPdo->exec($sql);
                } else {
                    $serverPdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                }
            }

            // 3. Connexion finale à la base 'terraconnect'
            $pdo = new PDO(
                "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
                $username,
                $password,
                $options
            );

            // 4. Vérifier si la table 'parcelles' existe (au cas où la base était vide)
            $stmtTbl = $pdo->query("SHOW TABLES LIKE 'parcelles'");
            if ($stmtTbl->fetch() === false) {
                $sqlFile = dirname(__DIR__) . '/database.sql';
                if (file_exists($sqlFile)) {
                    $sql = file_get_contents($sqlFile);
                    $pdo->exec($sql);
                }
            }

            break 2;
        } catch (PDOException $e) {
            $lastError = $e->getMessage();
        }
    }
}

if (!$pdo) {
    die(
        "<div style='font-family:Segoe UI,sans-serif;max-width:650px;margin:40px auto;padding:20px;border:1px solid #fecaca;background:#fef2f2;color:#991b1b;border-radius:10px;'>"
        . "<h3>❌ Impossible de se connecter à MySQL (XAMPP)</h3>"
        . "<p><strong>Vérifiez que le service MySQL est démarré (en vert) dans XAMPP Control Panel.</strong></p>"
        . "<p><strong>Détail technique :</strong> " . htmlspecialchars($lastError) . "</p>"
        . "</div>"
    );
}
