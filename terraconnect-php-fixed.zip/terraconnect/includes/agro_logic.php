<?php
function calculerScoreFenetre(array $prev): string
{
    $pluie = (float) ($prev['pluie'] ?? 0);
    $vent = (float) ($prev['vent'] ?? 0);
    $tempMin = (float) ($prev['temp_min'] ?? 10);
    $tempMax = (float) ($prev['temp_max'] ?? 20);

    if ($pluie > 10 || $vent > 25 || $tempMin <= 2) {
        return 'DECONSEILLE';
    }
    if ($pluie > 2 || $vent > 18 || $tempMax > 33) {
        return 'VIGILANCE';
    }
    return 'FAVORABLE';
}

function evaluerActiviteSelonMeteo(string $activite, ?array $prev): array
{
    if (!$prev) {
        return [
            'statut' => 'VIGILANCE',
            'justification' => 'Aucune prévision enregistrée pour cette date : vérification manuelle requise.'
        ];
    }

    $pluie = (float) $prev['pluie'];
    $vent = (float) $prev['vent'];

    if ($activite === 'Pulvérisation / Traitement') {
        if ($pluie > 2 || $vent > 20) {
            return [
                'statut' => 'DECONSEILLE',
                'justification' => "Conditions défavorables (Pluie : {$pluie} mm, Vent : {$vent} km/h)."
            ];
        }
        return [
            'statut' => 'FAVORABLE',
            'justification' => "Fenêtre idéale : vent calme ({$vent} km/h) et temps sec."
        ];
    }

    if ($activite === 'Irrigation') {
        if ($pluie >= 8) {
            return [
                'statut' => 'DECONSEILLE',
                'justification' => "Pluie naturelle suffisante prévue ({$pluie} mm) : économisez l'eau."
            ];
        }
        return [
            'statut' => 'FAVORABLE',
            'justification' => "Faibles précipitations ({$pluie} mm) : irrigation recommandée."
        ];
    }

    $score = calculerScoreFenetre($prev);
    return [
        'statut' => $score,
        'justification' => "Température {$prev['temp_min']}°C–{$prev['temp_max']}°C, pluie {$pluie} mm, vent {$vent} km/h."
    ];
}
