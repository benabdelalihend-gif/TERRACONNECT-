document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  initLiveDiagnostic();
  initChartFromDataAttr();
});

function initTabs() {
  const buttons = document.querySelectorAll(".nav-btn[data-tab]");
  const panels = document.querySelectorAll(".tab-panel");
  if (!buttons.length || !panels.length) return;

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      buttons.forEach((b) => b.classList.remove("active"));
      panels.forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");

      const target = document.getElementById(`tab-${btn.dataset.tab}`);
      if (target) target.classList.add("active");
    });
  });
}

function initLiveDiagnostic() {
  const activiteEl = document.getElementById("planifActivite");
  const dateEl = document.getElementById("planifDate");
  const boxEl = document.getElementById("liveDiagnosticBox");
  const parcelleId = document.body.dataset.parcelleId;

  if (!activiteEl || !dateEl || !boxEl || !parcelleId) return;

  const fetchDiag = async () => {
    const activite = activiteEl.value;
    const datePrev = dateEl.value;
    if (!datePrev) return;

    const url = `api.php?parcelle_id=${encodeURIComponent(parcelleId)}&activite=${encodeURIComponent(activite)}&date_prev=${encodeURIComponent(datePrev)}`;
    try {
      const res = await fetch(url);
      const data = await res.json();
      boxEl.innerHTML = `
        <strong>Diagnostic Smart Agro-Window :</strong>
        <span class="status-pill ${data.statut}">${data.statut}</span> — ${data.justification}
      `;
    } catch (err) {
      boxEl.textContent = "Erreur lors du calcul du diagnostic.";
    }
  };

  activiteEl.addEventListener("change", fetchDiag);
  dateEl.addEventListener("change", fetchDiag);
}

function initChartFromDataAttr() {
  const canvas = document.getElementById("weatherChart");
  if (!canvas) return;

  let data = [];
  try {
    data = JSON.parse(canvas.dataset.previsions || "[]");
  } catch (e) {
    data = [];
  }

  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!data.length) return;

  const pad = 40;
  const w = canvas.width - pad * 2;
  const h = canvas.height - pad * 2;
  const stepX = w / Math.max(data.length - 1, 1);

  ctx.strokeStyle = "#cbd5e1";
  ctx.beginPath();
  ctx.moveTo(pad, pad);
  ctx.lineTo(pad, pad + h);
  ctx.lineTo(pad + w, pad + h);
  ctx.stroke();

  data.forEach((d, i) => {
    const x = pad + i * stepX;
    const pluie = Number(d.pluie || 0);
    const barH = Math.min((pluie / 30) * h, h);
    ctx.fillStyle = "rgba(59, 130, 246, 0.35)";
    ctx.fillRect(x - 12, pad + h - barH, 24, barH);
  });

  ctx.strokeStyle = "#2e6f40";
  ctx.lineWidth = 3;
  ctx.beginPath();
  data.forEach((d, i) => {
    const x = pad + i * stepX;
    const tempMax = Number(d.temp_max || 0);
    const y = pad + h - (tempMax / 40) * h;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.fillStyle = "#1e293b";
  ctx.font = "11px Segoe UI";
  data.forEach((d, i) => {
    const x = pad + i * stepX;
    const tempMax = Number(d.temp_max || 0);
    const y = pad + h - (tempMax / 40) * h;
    ctx.beginPath();
    ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillText(`${tempMax}°`, x - 10, y - 8);
    ctx.fillText(String(d.date_prev || "").slice(5), x - 14, pad + h + 16);
  });
}
