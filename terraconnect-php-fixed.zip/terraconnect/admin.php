<?php
session_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/agro_logic.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_parcelle') {
        $stmt = $pdo->prepare("INSERT INTO parcelles (nom, culture, superficie, coords) VALUES (:nom, :culture, :sup, :coords)");
        $stmt->execute([
            'nom' => trim($_POST['nom']),
            'culture' => trim($_POST['culture']),
            'sup' => (float) $_POST['superficie'],
            'coords' => trim($_POST['coords']),
        ]);
        $_SESSION['flash'] = "Nouvelle parcelle ajoutée.";
    }

    if ($action === 'add_prevision') {
        $stmt = $pdo->prepare("
            INSERT INTO previsions (parcelle_id, date_prev, temp_min, temp_max, pluie, humidite, vent)
            VALUES (:pid, :d, :tmin, :tmax, :pluie, :hum, :vent)
        ");
        $stmt->execute([
            'pid' => (int) $_POST['parcelle_id'],
            'd' => $_POST['date_prev'],
            'tmin' => (float) $_POST['temp_min'],
            'tmax' => (float) $_POST['temp_max'],
            'pluie' => (float) $_POST['pluie'],
            'hum' => (int) $_POST['humidite'],
            'vent' => (float) $_POST['vent'],
        ]);
        $_SESSION['flash'] = "Prévision météorologique enregistrée.";
    }

    if ($action === 'delete_prevision') {
        $stmt = $pdo->prepare("DELETE FROM previsions WHERE id = :id");
        $stmt->execute(['id' => (int) $_POST['id']]);
        $_SESSION['flash'] = "Prévision supprimée.";
    }

    if ($action === 'add_alerte') {
        $stmt = $pdo->prepare("
            INSERT INTO alertes (parcelle_id, type_alerte, criticite, message, active)
            VALUES (:pid, :type_a, :crit, :msg, 1)
        ");
        $stmt->execute([
            'pid' => (int) $_POST['parcelle_id'],
            'type_a' => $_POST['type_alerte'],
            'crit' => $_POST['criticite'],
            'msg' => trim($_POST['message']),
        ]);
        $_SESSION['flash'] = "Alerte météo publiée.";
    }

    if ($action === 'toggle_alerte') {
        $stmt = $pdo->prepare("UPDATE alertes SET active = IF(active = 1, 0, 1) WHERE id = :id");
        $stmt->execute(['id' => (int) $_POST['id']]);
        $_SESSION['flash'] = "Statut de l'alerte mis à jour.";
    }

    header("Location: admin.php");
    exit;
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$parcelles = $pdo->query("SELECT * FROM parcelles ORDER BY id ASC")->fetchAll();
$previsions = $pdo->query("
    SELECT pr.*, pa.nom AS parcelle_nom
    FROM previsions pr
    JOIN parcelles pa ON pa.id = pr.parcelle_id
    ORDER BY pr.date_prev DESC, pr.id DESC
")->fetchAll();

$alertes = $pdo->query("
    SELECT al.*, pa.nom AS parcelle_nom
    FROM alertes al
    JOIN parcelles pa ON pa.id = al.parcelle_id
    ORDER BY al.id DESC
")->fetchAll();

$nbReleves = (int) $pdo->query("SELECT COUNT(*) FROM donnees_climatiques")->fetchColumn();
$nbPlanifs = (int) $pdo->query("SELECT COUNT(*) FROM planifications")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>TerraConnect — Backoffice Administrateur</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <aside class="sidebar">
    <div class="brand">
      <div class="brand-logo">🛠️</div>
      <div>
        <h1>TerraConnect</h1>
        <span>Backoffice Admin</span>
      </div>
    </div>

    <nav class="nav-menu">
      <button type="button" class="nav-btn active" data-tab="admin-previsions">🌦️ Gérer Prévisions</button>
      <button type="button" class="nav-btn" data-tab="admin-alertes">🚨 Gérer Alertes</button>
      <button type="button" class="nav-btn" data-tab="admin-parcelles">📍 Gérer Parcelles</button>
      <a href="index.php" class="nav-btn" style="margin-top:8px; background:rgba(255,255,255,0.12); text-decoration:none;">
        👨‍🌾 Retour Frontoffice
      </a>
    </nav>
  </aside>

  <main class="main-content">
    <header class="topbar">
      <div>
        <h2>Backoffice — Administration TerraConnect</h2>
        <p>Gestion des parcelles, prévisions météorologiques et alertes</p>
      </div>
      <span class="role-pill">Mode : Administrateur</span>
    </header>

    <?php if ($flash): ?>
      <div class="diagnostic-box" style="margin:0 0 18px 0;">
        ✅ <?= htmlspecialchars($flash) ?>
      </div>
    <?php endif; ?>

    <div class="kpi-grid" style="margin-bottom:20px;">
      <div class="kpi-card"><span>Parcelles</span><strong><?= count($parcelles) ?></strong></div>
      <div class="kpi-card"><span>Prévisions</span><strong><?= count($previsions) ?></strong></div>
      <div class="kpi-card"><span>Relevés Climatiques</span><strong><?= $nbReleves ?></strong></div>
      <div class="kpi-card"><span>Planifications</span><strong><?= $nbPlanifs ?></strong></div>
    </div>

    <!-- ADMIN PREVISIONS -->
    <section id="tab-admin-previsions" class="tab-panel active">
      <div class="card">
        <div class="card-header"><h3>➕ Ajouter une prévision météorologique</h3></div>
        <form method="POST" class="form-grid">
          <input type="hidden" name="action" value="add_prevision" />
          <select name="parcelle_id" required>
            <?php foreach ($parcelles as $p): ?>
              <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nom']) ?></option>
            <?php endforeach; ?>
          </select>
          <input type="date" name="date_prev" required />
          <input type="number" step="0.1" name="temp_min" placeholder="Temp. Min (°C)" required />
          <input type="number" step="0.1" name="temp_max" placeholder="Temp. Max (°C)" required />
          <input type="number" step="0.1" name="pluie" placeholder="Précipitations (mm)" required />
          <input type="number" step="1" name="humidite" placeholder="Humidité (%)" required />
          <input type="number" step="0.1" name="vent" placeholder="Vent (km/h)" required />
          <button type="submit" class="btn-primary">Enregistrer</button>
        </form>
      </div>

      <div class="card">
        <div class="card-header"><h3>📋 Liste des prévisions</h3></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Parcelle</th>
                <th>Date</th>
                <th>Temp Min/Max</th>
                <th>Pluie</th>
                <th>Vent</th>
                <th>Score Agro</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($previsions as $pr): $score = calculerScoreFenetre($pr); ?>
                <tr>
                  <td><strong><?= htmlspecialchars($pr['parcelle_nom']) ?></strong></td>
                  <td><?= htmlspecialchars($pr['date_prev']) ?></td>
                  <td><?= $pr['temp_min'] ?>°C / <?= $pr['temp_max'] ?>°C</td>
                  <td><?= $pr['pluie'] ?> mm</td>
                  <td><?= $pr['vent'] ?> km/h</td>
                  <td><span class="status-pill <?= $score ?>"><?= $score ?></span></td>
                  <td>
                    <form method="POST" onsubmit="return confirm('Supprimer cette prévision ?');">
                      <input type="hidden" name="action" value="delete_prevision" />
                      <input type="hidden" name="id" value="<?= $pr['id'] ?>" />
                      <button type="submit" class="btn-danger">Supprimer</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- ADMIN ALERTES -->
    <section id="tab-admin-alertes" class="tab-panel">
      <div class="card">
        <div class="card-header"><h3>🚨 Publier une alerte météo</h3></div>
        <form method="POST" class="form-grid">
          <input type="hidden" name="action" value="add_alerte" />
          <select name="parcelle_id" required>
            <?php foreach ($parcelles as $p): ?>
              <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nom']) ?></option>
            <?php endforeach; ?>
          </select>
          <select name="type_alerte" required>
            <option value="GEL">GEL</option>
            <option value="CANICULE">CANICULE</option>
            <option value="FORTE_PLUIE">FORTE_PLUIE</option>
            <option value="VENT_FORT">VENT_FORT</option>
            <option value="STRESS_HYDRIQUE">STRESS_HYDRIQUE</option>
          </select>
          <select name="criticite" required>
            <option value="FAIBLE">FAIBLE</option>
            <option value="MOYEN">MOYEN</option>
            <option value="ELEVE">ELEVE</option>
          </select>
          <input type="text" name="message" placeholder="Message d'alerte détaillé..." required />
          <button type="submit" class="btn-primary">Publier</button>
        </form>
      </div>

      <div class="card">
        <div class="card-header"><h3>⚠️ Toutes les alertes</h3></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Parcelle</th>
                <th>Type</th>
                <th>Criticité</th>
                <th>Message</th>
                <th>État</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($alertes as $al): ?>
                <tr>
                  <td><strong><?= htmlspecialchars($al['parcelle_nom']) ?></strong></td>
                  <td><?= htmlspecialchars($al['type_alerte']) ?></td>
                  <td><?= htmlspecialchars($al['criticite']) ?></td>
                  <td><?= htmlspecialchars($al['message']) ?></td>
                  <td><?= (int)$al['active'] === 1 ? 'Active' : 'Acquittée' ?></td>
                  <td>
                    <form method="POST">
                      <input type="hidden" name="action" value="toggle_alerte" />
                      <input type="hidden" name="id" value="<?= $al['id'] ?>" />
                      <button type="submit" class="btn-ack">Basculer état</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- ADMIN PARCELLES -->
    <section id="tab-admin-parcelles" class="tab-panel">
      <div class="card">
        <div class="card-header"><h3>➕ Ajouter une parcelle</h3></div>
        <form method="POST" class="form-grid">
          <input type="hidden" name="action" value="add_parcelle" />
          <input type="text" name="nom" placeholder="Nom parcelle (ex: Parcelle Ouest)" required />
          <input type="text" name="culture" placeholder="Culture (ex: Tomate)" required />
          <input type="number" step="0.1" name="superficie" placeholder="Superficie (ha)" required />
          <input type="text" name="coords" placeholder="Coords (ex: 36.70° N, 10.10° E)" required />
          <button type="submit" class="btn-primary">Ajouter</button>
        </form>
      </div>

      <div class="card">
        <div class="card-header"><h3>📍 Parcelles enregistrées</h3></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Culture</th>
                <th>Superficie</th>
                <th>Coordonnées</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($parcelles as $p): ?>
                <tr>
                  <td><?= $p['id'] ?></td>
                  <td><strong><?= htmlspecialchars($p['nom']) ?></strong></td>
                  <td><?= htmlspecialchars($p['culture']) ?></td>
                  <td><?= $p['superficie'] ?> ha</td>
                  <td><?= htmlspecialchars($p['coords']) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>

  <script src="script.js"></script>
</body>
</html>
