<?php
session_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/agro_logic.php';

$parcelles = $pdo->query("SELECT * FROM parcelles ORDER BY id ASC")->fetchAll();
if (!$parcelles) {
    die("Aucune parcelle trouvée. Exécutez database.sql.");
}

$currentParcelleId = isset($_GET['parcelle_id']) ? (int) $_GET['parcelle_id'] : (int) $parcelles[0]['id'];
$currentParcelle = null;
foreach ($parcelles as $p) {
    if ((int) $p['id'] === $currentParcelleId) {
        $currentParcelle = $p;
        break;
    }
}
if (!$currentParcelle) {
    $currentParcelle = $parcelles[0];
    $currentParcelleId = (int) $currentParcelle['id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $pid = (int) ($_POST['parcelle_id'] ?? $currentParcelleId);

    if ($action === 'add_climat') {
        $stmt = $pdo->prepare("
            INSERT INTO donnees_climatiques (parcelle_id, date_releve, source, temp, pluie, humidite_sol)
            VALUES (:pid, NOW(), :source, :temp, :pluie, :hum)
        ");
        $stmt->execute([
            'pid' => $pid,
            'source' => $_POST['source'],
            'temp' => (float) $_POST['temp'],
            'pluie' => (float) $_POST['pluie'],
            'hum' => (float) $_POST['humidite_sol'],
        ]);
        $_SESSION['flash'] = "Relevé climatique ajouté avec succès.";
    }

    if ($action === 'add_planif') {
        $datePrev = $_POST['date_prev'];
        $activite = $_POST['activite'];

        $stmtPrev = $pdo->prepare("SELECT * FROM previsions WHERE parcelle_id = :pid AND date_prev = :d LIMIT 1");
        $stmtPrev->execute(['pid' => $pid, 'd' => $datePrev]);
        $prev = $stmtPrev->fetch() ?: null;

        $eval = evaluerActiviteSelonMeteo($activite, $prev);

        $stmtIns = $pdo->prepare("
            INSERT INTO planifications (parcelle_id, date_prev, activite, statut, justification)
            VALUES (:pid, :d, :act, :statut, :justif)
        ");
        $stmtIns->execute([
            'pid' => $pid,
            'd' => $datePrev,
            'act' => $activite,
            'statut' => $eval['statut'],
            'justif' => $eval['justification'],
        ]);
        $_SESSION['flash'] = "Activité planifiée ({$eval['statut']}).";
    }

    if ($action === 'ack_alerte') {
        $alerteId = (int) $_POST['alerte_id'];
        $stmtAck = $pdo->prepare("UPDATE alertes SET active = 0 WHERE id = :id AND parcelle_id = :pid");
        $stmtAck->execute(['id' => $alerteId, 'pid' => $pid]);
        $_SESSION['flash'] = "Alerte acquittée.";
    }

    header("Location: index.php?parcelle_id=" . $pid);
    exit;
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$stmtPrev = $pdo->prepare("SELECT * FROM previsions WHERE parcelle_id = :pid ORDER BY date_prev ASC");
$stmtPrev->execute(['pid' => $currentParcelleId]);
$previsions = $stmtPrev->fetchAll();

$stmtClim = $pdo->prepare("SELECT * FROM donnees_climatiques WHERE parcelle_id = :pid ORDER BY date_releve DESC");
$stmtClim->execute(['pid' => $currentParcelleId]);
$climatList = $stmtClim->fetchAll();

$stmtPlan = $pdo->prepare("SELECT * FROM planifications WHERE parcelle_id = :pid ORDER BY date_prev DESC, id DESC");
$stmtPlan->execute(['pid' => $currentParcelleId]);
$planifList = $stmtPlan->fetchAll();

$stmtAlert = $pdo->prepare("SELECT * FROM alertes WHERE parcelle_id = :pid ORDER BY active DESC, id DESC");
$stmtAlert->execute(['pid' => $currentParcelleId]);
$alertes = $stmtAlert->fetchAll();

$nextPrev = $previsions[0] ?? null;
$cumulPluie = array_reduce($previsions, fn($carry, $item) => $carry + (float) $item['pluie'], 0.0);
$activeAlerts = array_values(array_filter($alertes, fn($a) => (int) $a['active'] === 1));
$lastClim = $climatList[0] ?? null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>TerraConnect — Frontoffice Agriculteur</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body data-parcelle-id="<?= $currentParcelleId ?>">
  <aside class="sidebar">
    <div class="brand">
      <div class="brand-logo">🌿</div>
      <div>
        <h1>TerraConnect</h1>
        <span>Frontoffice Agriculteur</span>
      </div>
    </div>

    <form method="GET" class="control-group">
      <label for="parcelleSelect">Parcelle active</label>
      <select id="parcelleSelect" name="parcelle_id" onchange="this.form.submit()">
        <?php foreach ($parcelles as $p): ?>
          <option value="<?= $p['id'] ?>" <?= (int)$p['id'] === $currentParcelleId ? 'selected' : '' ?>>
            <?= htmlspecialchars($p['nom']) ?> (<?= htmlspecialchars($p['culture']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </form>

    <nav class="nav-menu">
      <button type="button" class="nav-btn active" data-tab="dashboard">📊 Tableau de bord</button>
      <button type="button" class="nav-btn" data-tab="previsions">🌦️ Prévisions Météo</button>
      <button type="button" class="nav-btn" data-tab="climat">🌡️ Données Climatiques</button>
      <button type="button" class="nav-btn" data-tab="planification">📅 Planification Activités</button>
      <button type="button" class="nav-btn" data-tab="alertes">
        ⚠️ Alertes Météo <span class="badge-count"><?= count($activeAlerts) ?></span>
      </button>
      <a href="admin.php" class="nav-btn" style="margin-top:8px; background:rgba(255,255,255,0.12); text-decoration:none;">
        🛠️ Aller au Backoffice
      </a>
    </nav>

    <div class="parcelle-card">
      <strong>📍 <?= htmlspecialchars($currentParcelle['nom']) ?></strong><br/>
      Culture : <?= htmlspecialchars($currentParcelle['culture']) ?><br/>
      Superficie : <?= htmlspecialchars($currentParcelle['superficie']) ?> ha<br/>
      GPS : <?= htmlspecialchars($currentParcelle['coords']) ?>
    </div>
  </aside>

  <main class="main-content">
    <header class="topbar">
      <div>
        <h2>Espace Agriculteur — <?= htmlspecialchars($currentParcelle['nom']) ?></h2>
        <p>Suivi météo, relevés terrain et planification intelligente</p>
      </div>
      <span class="role-pill">Frontoffice : Agriculteur</span>
    </header>

    <?php if ($flash): ?>
      <div class="diagnostic-box" style="margin:0 0 18px 0;">
        ✅ <?= htmlspecialchars($flash) ?>
      </div>
    <?php endif; ?>

    <!-- TAB 1: DASHBOARD -->
    <section id="tab-dashboard" class="tab-panel active">
      <div class="kpi-grid">
        <div class="kpi-card">
          <span>Prochaine Température (Min/Max)</span>
          <strong><?= $nextPrev ? "{$nextPrev['temp_min']}° / {$nextPrev['temp_max']}°C" : "N/A" ?></strong>
        </div>
        <div class="kpi-card">
          <span>Cumul Pluie Prévu</span>
          <strong><?= number_format($cumulPluie, 1) ?> mm</strong>
        </div>
        <div class="kpi-card">
          <span>Humidité Sol (Dernier relevé)</span>
          <strong><?= $lastClim ? "{$lastClim['humidite_sol']}%" : "N/A" ?></strong>
        </div>
        <div class="kpi-card">
          <span>Alertes Météo Actives</span>
          <strong><?= count($activeAlerts) ?></strong>
        </div>
      </div>

      <div class="two-col-grid">
        <div class="card">
          <div class="card-header"><h3>📈 Températures Max (°C) & Précipitations (mm)</h3></div>
          <canvas id="weatherChart" width="600" height="260" data-previsions='<?= htmlspecialchars(json_encode($previsions), ENT_QUOTES, "UTF-8") ?>'></canvas>
        </div>

        <div class="card">
          <div class="card-header"><h3>🚦 Fenêtres d'intervention (Smart Agro-Window)</h3></div>
          <div class="stack-list">
            <?php foreach ($previsions as $p): $score = calculerScoreFenetre($p); ?>
              <div class="list-item">
                <div>
                  <strong><?= htmlspecialchars($p['date_prev']) ?></strong> —
                  <?= $p['temp_min'] ?>°C à <?= $p['temp_max'] ?>°C | Pluie: <?= $p['pluie'] ?> mm
                </div>
                <span class="status-pill <?= $score ?>"><?= $score ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><h3>🚨 Alertes actives sur la parcelle</h3></div>
        <div class="stack-list">
          <?php if (!$activeAlerts): ?>
            <p>Aucune alerte active sur cette parcelle.</p>
          <?php else: ?>
            <?php foreach ($activeAlerts as $a): ?>
              <div class="alert-item <?= $a['criticite'] ?>">
                <div>
                  <strong>[<?= htmlspecialchars($a['type_alerte']) ?> — Criticité : <?= htmlspecialchars($a['criticite']) ?>]</strong>
                  <p><?= htmlspecialchars($a['message']) ?></p>
                </div>
                <form method="POST">
                  <input type="hidden" name="action" value="ack_alerte" />
                  <input type="hidden" name="parcelle_id" value="<?= $currentParcelleId ?>" />
                  <input type="hidden" name="alerte_id" value="<?= $a['id'] ?>" />
                  <button type="submit" class="btn-ack">Acquitter</button>
                </form>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </section>

    <!-- TAB 2: PREVISIONS -->
    <section id="tab-previsions" class="tab-panel">
      <div class="card">
        <div class="card-header"><h3>🌦️ Prévisions détaillées par date</h3></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Temp. Min / Max</th>
                <th>Précipitations</th>
                <th>Humidité</th>
                <th>Vent</th>
                <th>Score Fenêtre Agro</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($previsions as $p): $score = calculerScoreFenetre($p); ?>
                <tr>
                  <td><strong><?= htmlspecialchars($p['date_prev']) ?></strong></td>
                  <td><?= $p['temp_min'] ?>°C / <?= $p['temp_max'] ?>°C</td>
                  <td><?= $p['pluie'] ?> mm</td>
                  <td><?= $p['humidite'] ?>%</td>
                  <td><?= $p['vent'] ?> km/h</td>
                  <td><span class="status-pill <?= $score ?>"><?= $score ?></span></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- TAB 3: CLIMAT -->
    <section id="tab-climat" class="tab-panel">
      <div class="card">
        <div class="card-header"><h3>➕ Enregistrer un relevé climatique</h3></div>
        <form method="POST" class="form-grid">
          <input type="hidden" name="action" value="add_climat" />
          <input type="hidden" name="parcelle_id" value="<?= $currentParcelleId ?>" />
          <select name="source" required>
            <option value="CAPTEUR_IOT">CAPTEUR_IOT</option>
            <option value="API_METEO">API_METEO</option>
            <option value="SAISIE_MANUELLE">SAISIE_MANUELLE</option>
          </select>
          <input type="number" step="0.1" name="temp" placeholder="Température (°C)" required />
          <input type="number" step="0.1" name="pluie" placeholder="Précipitations (mm)" required />
          <input type="number" step="0.1" name="humidite_sol" placeholder="Humidité du sol (%)" required />
          <button type="submit" class="btn-primary">Ajouter le relevé</button>
        </form>
      </div>

      <div class="card">
        <div class="card-header"><h3>📋 Historique des données climatiques</h3></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Date & Heure</th>
                <th>Source</th>
                <th>Température</th>
                <th>Précipitations</th>
                <th>Humidité Sol</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($climatList as $c): ?>
                <tr>
                  <td><?= htmlspecialchars($c['date_releve']) ?></td>
                  <td><strong><?= htmlspecialchars($c['source']) ?></strong></td>
                  <td><?= $c['temp'] ?> °C</td>
                  <td><?= $c['pluie'] ?> mm</td>
                  <td><?= $c['humidite_sol'] ?>%</td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- TAB 4: PLANIFICATION -->
    <section id="tab-planification" class="tab-panel">
      <div class="card">
        <div class="card-header"><h3>📅 Planifier une activité agricole selon la météo</h3></div>
        <form method="POST" class="form-grid" id="planifFormPhp">
          <input type="hidden" name="action" value="add_planif" />
          <input type="hidden" name="parcelle_id" value="<?= $currentParcelleId ?>" />
          <select name="activite" id="planifActivite" required>
            <option value="Pulvérisation / Traitement">Pulvérisation / Traitement</option>
            <option value="Irrigation">Irrigation</option>
            <option value="Semis">Semis</option>
            <option value="Récolte">Récolte</option>
          </select>
          <input type="date" name="date_prev" id="planifDate" required />
          <button type="submit" class="btn-primary">Évaluer & Planifier</button>
        </form>
        <div id="liveDiagnosticBox" class="diagnostic-box">
          Sélectionnez une activité et une date pour obtenir le diagnostic météo automatique.
        </div>
      </div>

      <div class="card">
        <div class="card-header"><h3>🗂️ Activités planifiées sur la parcelle</h3></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Date prévue</th>
                <th>Activité</th>
                <th>Recommandation</th>
                <th>Justification Météo</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($planifList as $pl): ?>
                <tr>
                  <td><strong><?= htmlspecialchars($pl['date_prev']) ?></strong></td>
                  <td><?= htmlspecialchars($pl['activite']) ?></td>
                  <td><span class="status-pill <?= $pl['statut'] ?>"><?= $pl['statut'] ?></span></td>
                  <td><?= htmlspecialchars($pl['justification']) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- TAB 5: ALERTES -->
    <section id="tab-alertes" class="tab-panel">
      <div class="card">
        <div class="card-header"><h3>⚠️ Journal des alertes météorologiques</h3></div>
        <div class="stack-list">
          <?php foreach ($alertes as $a): ?>
            <div class="alert-item <?= $a['criticite'] ?>">
              <div>
                <strong>[<?= htmlspecialchars($a['type_alerte']) ?> — Criticité : <?= htmlspecialchars($a['criticite']) ?>]</strong>
                <p><?= htmlspecialchars($a['message']) ?></p>
              </div>
              <?php if ((int)$a['active'] === 1): ?>
                <form method="POST">
                  <input type="hidden" name="action" value="ack_alerte" />
                  <input type="hidden" name="parcelle_id" value="<?= $currentParcelleId ?>" />
                  <input type="hidden" name="alerte_id" value="<?= $a['id'] ?>" />
                  <button type="submit" class="btn-ack">Acquitter</button>
                </form>
              <?php else: ?>
                <span>✅ Acquittée</span>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </section>
  </main>

  <script src="script.js"></script>
</body>
</html>
