<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/agro_logic.php';

$parcelleId = isset($_GET['parcelle_id']) ? (int) $_GET['parcelle_id'] : 1;
$activite = $_GET['activite'] ?? 'Pulvérisation / Traitement';
$datePrev = $_GET['date_prev'] ?? '';

$prev = null;
if ($datePrev !== '') {
    $stmt = $pdo->prepare("SELECT * FROM previsions WHERE parcelle_id = :pid AND date_prev = :d LIMIT 1");
    $stmt->execute(['pid' => $parcelleId, 'd' => $datePrev]);
    $row = $stmt->fetch();
    if ($row) {
        $prev = $row;
    }
}

$eval = evaluerActiviteSelonMeteo($activite, $prev);
echo json_encode($eval);
