CREATE DATABASE IF NOT EXISTS terraconnect CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE terraconnect;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS alertes;
DROP TABLE IF EXISTS planifications;
DROP TABLE IF EXISTS donnees_climatiques;
DROP TABLE IF EXISTS previsions;
DROP TABLE IF EXISTS parcelles;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE parcelles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  culture VARCHAR(100) NOT NULL,
  superficie DECIMAL(6,2) NOT NULL,
  coords VARCHAR(100) NOT NULL
);

CREATE TABLE previsions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parcelle_id INT NOT NULL,
  date_prev DATE NOT NULL,
  temp_min DECIMAL(4,1) NOT NULL,
  temp_max DECIMAL(4,1) NOT NULL,
  pluie DECIMAL(5,1) NOT NULL DEFAULT 0,
  humidite INT NOT NULL DEFAULT 50,
  vent DECIMAL(5,1) NOT NULL DEFAULT 0,
  FOREIGN KEY (parcelle_id) REFERENCES parcelles(id) ON DELETE CASCADE
);

CREATE TABLE donnees_climatiques (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parcelle_id INT NOT NULL,
  date_releve DATETIME NOT NULL,
  source ENUM('CAPTEUR_IOT', 'API_METEO', 'SAISIE_MANUELLE') NOT NULL,
  temp DECIMAL(4,1) NOT NULL,
  pluie DECIMAL(5,1) NOT NULL DEFAULT 0,
  humidite_sol DECIMAL(5,1) NOT NULL DEFAULT 0,
  FOREIGN KEY (parcelle_id) REFERENCES parcelles(id) ON DELETE CASCADE
);

CREATE TABLE planifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parcelle_id INT NOT NULL,
  date_prev DATE NOT NULL,
  activite VARCHAR(100) NOT NULL,
  statut ENUM('FAVORABLE', 'VIGILANCE', 'DECONSEILLE') NOT NULL,
  justification TEXT NOT NULL,
  FOREIGN KEY (parcelle_id) REFERENCES parcelles(id) ON DELETE CASCADE
);

CREATE TABLE alertes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parcelle_id INT NOT NULL,
  type_alerte ENUM('GEL', 'CANICULE', 'FORTE_PLUIE', 'VENT_FORT', 'STRESS_HYDRIQUE') NOT NULL,
  criticite ENUM('FAIBLE', 'MOYEN', 'ELEVE') NOT NULL,
  message TEXT NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (parcelle_id) REFERENCES parcelles(id) ON DELETE CASCADE
);

INSERT INTO parcelles (id, nom, culture, superficie, coords) VALUES
(1, 'Parcelle Nord', 'Blé dur', 12.50, '36.81° N, 10.18° E'),
(2, 'Parcelle Sud', 'Olivier', 18.00, '35.82° N, 10.63° E'),
(3, 'Parcelle Est', 'Agrumes', 8.40, '36.45° N, 10.73° E');

INSERT INTO previsions (parcelle_id, date_prev, temp_min, temp_max, pluie, humidite, vent) VALUES
(1, '2026-11-25', 9.5, 19.0, 0.0, 58, 12.0),
(1, '2026-11-26', 8.0, 16.5, 14.5, 82, 28.0),
(1, '2026-11-27', 6.5, 15.0, 4.0, 74, 21.0),
(1, '2026-11-28', 10.0, 20.5, 0.0, 52, 10.0),
(1, '2026-11-29', 11.0, 22.0, 0.0, 48, 14.0),
(2, '2026-11-25', 12.0, 23.0, 0.0, 45, 15.0),
(2, '2026-11-26', 13.5, 25.0, 0.0, 40, 34.0),
(2, '2026-11-27', 11.0, 21.0, 2.5, 60, 16.0),
(3, '2026-11-25', 10.5, 20.0, 18.0, 88, 30.0),
(3, '2026-11-26', 11.0, 21.5, 0.0, 55, 11.0);

INSERT INTO donnees_climatiques (parcelle_id, date_releve, source, temp, pluie, humidite_sol) VALUES
(1, '2026-11-24 08:00:00', 'CAPTEUR_IOT', 14.2, 0.0, 42.0),
(1, '2026-11-23 14:00:00', 'API_METEO', 18.6, 2.4, 46.0),
(2, '2026-11-24 08:30:00', 'CAPTEUR_IOT', 17.8, 0.0, 31.0),
(3, '2026-11-24 09:00:00', 'SAISIE_MANUELLE', 16.4, 5.2, 54.0);

INSERT INTO planifications (parcelle_id, date_prev, activite, statut, justification) VALUES
(1, '2026-11-25', 'Pulvérisation / Traitement', 'FAVORABLE', 'Vent faible (12 km/h) et aucune pluie prévue.'),
(1, '2026-11-26', 'Pulvérisation / Traitement', 'DECONSEILLE', 'Pluie prévue (14.5 mm) et vent soutenu (28 km/h) : risque de lessivage.');

INSERT INTO alertes (parcelle_id, type_alerte, criticite, message, active) VALUES
(1, 'FORTE_PLUIE', 'ELEVE', 'Cumul de 14.5 mm attendu le 26/11 : reporter les traitements foliaires.', 1),
(2, 'VENT_FORT', 'MOYEN', 'Rafales à 34 km/h prévues le 26/11 sur la parcelle d''oliviers.', 1),
(3, 'FORTE_PLUIE', 'ELEVE', 'Précipitations intenses (18 mm) le 25/11 : vérifier le drainage.', 1);
