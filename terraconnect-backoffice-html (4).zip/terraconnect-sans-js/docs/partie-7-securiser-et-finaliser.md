# Partie 7 : Sécuriser et finaliser ton projet

## 7.1. Hachage des mots de passe

Déjà mis en place via `password_hash()` / `password_verify()`. Vérifie que **toutes** les créations de compte (pas seulement le formulaire principal) passent par `password_hash()`.

## 7.2. Injections SQL

Un code vulnérable construit la requête par concaténation directe du champ saisi, sans distinguer « code SQL » et « donnée ».

**Requête normalement attendue**

```sql
SELECT * FROM users WHERE email = 'utilisateur@exemple.com'
```

**Requête réellement construite si l'attaquant saisit `' OR '1'='1` dans le champ email**

```sql
SELECT * FROM users WHERE email = '' OR '1'='1'
```

**Conséquence** : `'1'='1'` est toujours vraie → la requête retourne le premier utilisateur de la table, sans connaître son mot de passe.

**Code vulnérable (à NE JAMAIS reproduire)**

```php
$sql = "SELECT * FROM users WHERE email='".$_POST['email']."'";
$pdo->query($sql); // injectable : ' OR '1'='1
```

Ton Controller utilise déjà des requêtes préparées depuis la Partie 3, donc ton projet est déjà protégé :

```php
$stmt = $this->db->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
$stmt->execute(['email' => $email]);
```

### Tester la protection

1. Ouvrez `index.php?action=login`. Avec les outils de développement (F12 → onglet Éléments), changez l'attribut `type="email"` du champ email en `type="text"` (sinon le navigateur bloque ce texte avant l'envoi).
2. Saisissez `' OR '1'='1` comme email et n'importe quel mot de passe, puis validez.
3. Vérifiez que la connexion échoue (« Incorrect email or password. ») : la saisie est traitée comme une donnée, jamais comme du code SQL.

## 7.3. Failles XSS

Une faille XSS survient quand une application affiche, sans le filtrer, un contenu saisi par un utilisateur. Le navigateur de la victime l'exécute alors comme du code.

**Déjà en place dans tes Vues (Parties 4 à 6)**

```php
<?= htmlspecialchars($user->getUsername(), ENT_QUOTES, 'UTF-8') ?>
```

### Test XSS neutralisé

1. Essayez d'abord de vous inscrire avec le nom d'utilisateur `<script>alert('test')</script>` : le formulaire le refuse (« Username must be 3 to 50 characters (letters, digits, _ or -). »). C'est une première barrière : la validation des entrées.
2. Pour tester la seconde barrière (l'échappement en sortie), insérez directement un compte piégé avec phpMyAdmin (onglet SQL) :

```sql
-- NB: inside an SQL string, a single quote is written twice ('')
INSERT INTO users (username, email, password, role) VALUES
('<script>alert(''test'')</script>', 'xsstest@example.com',
'$2y$10$B9OJgl/Y9A05dLd4TYZtsuZ2.qLbFcnJYdxLHcije9.Z/hhkDxkcq', 'user');
-- password of this test account: User@1234
```

3. Connectez-vous et accédez à votre espace utilisateur. Vérifiez que le nom d'utilisateur est affiché sous forme de texte brut, sans exécuter le script ni afficher de fenêtre contextuelle (popup).

## 7.4. Failles CSRF

Le CSRF exploite le fait que le navigateur d'une victime déjà connectée envoie automatiquement ses cookies de session à chaque requête vers ce site, même déclenchée depuis un site tiers.

**Déroulement d'une attaque CSRF**

1. La victime est connectée sur ton `site.local`.
2. Elle visite un site malveillant.
3. Ce site déclenche un formulaire vers ton `site.local`.
4. Le navigateur joint automatiquement le cookie.
5. L'action est exécutée à l'insu de la victime.

### Mise en place

**1.** Ouvrez `AuthController.php` ainsi que les fichiers contenant vos formulaires d'authentification (`views/register.php` et `views/login.php`).

**2.** Ajoutez les deux méthodes suivantes dans la classe `AuthController` :

```php
// ==============================================================
// CSRF
// ==============================================================
public function getCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

private function verifyCsrfToken(?string $token): bool
{
    if (!$token || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}
```

**3.** Ajoutez la vérification du token CSRF au tout début des méthodes `register()` et `login()`, juste après `$errors = [];`, afin de contrôler que les requêtes reçues proviennent bien de votre application :

```php
if (!$this->verifyCsrfToken($post['csrf_token'] ?? null)) {
    $errors[] = "Invalid security token. Please try again.";
    return $errors;
}
```

**4.** Dans `index.php`, transmettez le token aux vues : ajoutez `$csrfToken = $authController->getCsrfToken();` juste avant `require __DIR__ . '/views/register.php';` (cas `register`) et juste avant `require __DIR__ . '/views/login.php';` (cas `login`) :

```php
$csrfToken = $authController->getCsrfToken();
require __DIR__ . '/views/register.php'; // case 'register' (same idea in case 'login')
break;
```

**5.** Ouvrez `views/register.php` et `views/login.php`, placez-vous juste après la balise d'ouverture `<form …>` de chaque formulaire et ajoutez le champ caché suivant :

```php
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
```

> Si vous oubliez l'étape 4, PHP signale « Undefined variable $csrfToken » ; si vous oubliez l'étape 5, chaque envoi de formulaire affiche « Invalid security token. Please try again. ».

## 7.5. En-têtes HTTP de sécurité

Pour terminer, le serveur peut demander au navigateur d'activer des protections supplémentaires grâce à des en-têtes HTTP. Dans `index.php`, ajoutez le bloc suivant juste après le bloc d'expiration de session (5.5) et avant les `require_once` :

```php
// HTTP security headers
header('X-Frame-Options: DENY'); // anti clickjacking
header('X-Content-Type-Options: nosniff'); // prevents MIME-sniffing
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'"); // limits XSS
```

### Vocabulaire clé

- **X-Frame-Options: DENY** : interdit d'afficher votre site dans une iframe d'un autre site (protection contre le clickjacking).
- **X-Content-Type-Options: nosniff** : empêche le navigateur de deviner le type d'un fichier.
- **Referrer-Policy** : limite les informations d'origine envoyées aux autres sites.
- **Content-Security-Policy** : liste les sources que le navigateur accepte de charger (scripts, styles...) ; seconde barrière contre le XSS.

Si votre site est servi en HTTPS, décommentez aussi la ligne `session.cookie_secure` du bloc écrit en 5.5.

**Ordre final du début de votre fichier `index.php` :**

```php
<?php
declare(strict_types=1);
// 1. Secure session configuration (ini_set... + session_start)
// 2. Session expiration due to inactivity
// 3. HTTP security headers
// 4. require_once ... + $authController = new AuthController();
// 5. Routing: $action =
```

## 7.6. Récapitulatif

| Risque | Protection mise en place | Où ? |
|---|---|---|
| Injection SQL | Requêtes préparées PDO + `ATTR_EMULATE_PREPARES = false` | AuthController, database.php |
| Mots de passe en clair | `password_hash()` / `password_verify()` | `register()`, `login()` |
| XSS | `htmlspecialchars()` en sortie, validation des entrées, en-tête Content-Security-Policy | Vues, `register()`, `index.php` |
| CSRF | Token unique par session, vérifié avec `hash_equals()` | AuthController, formulaires |
| Fixation de session | `session_regenerate_id(true)` après connexion | `login()` |
| Vol de session via JavaScript | Cookie HttpOnly + SameSite=Lax | `index.php` |
| Clickjacking | `X-Frame-Options: DENY` | `index.php` |
| Élévation de privilèges | Rôle forcé à `'user'` à l'inscription, `requireRole()` sur chaque page sensible | `register()`, `index.php` |
| Sessions abandonnées | Expiration après 30 minutes d'inactivité | `index.php` |

Vous disposez maintenant d'un projet complet, réutilisable comme modèle pour n'importe quel projet web : architecture MVC, authentification, gestion des rôles et protections de base.
