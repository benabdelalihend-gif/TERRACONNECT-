-- Test XSS (7.3) : compte "piégé" pour vérifier l'échappement en sortie.
-- NB: inside an SQL string, a single quote is written twice ('')
USE terraconnect;
INSERT INTO users (username, email, password, role) VALUES
('<script>alert(''test'')</script>', 'xsstest@example.com',
'$2y$10$B9OJgl/Y9A05dLd4TYZtsuZ2.qLbFcnJYdxLHcije9.Z/hhkDxkcq', 'user');
-- password of this test account: User@1234
-- Nettoyage : DELETE FROM users WHERE email = 'xsstest@example.com';
