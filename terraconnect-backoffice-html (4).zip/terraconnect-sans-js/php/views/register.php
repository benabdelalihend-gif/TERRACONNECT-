<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TerraConnect - Créer un compte</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="assets/auth.css">
</head>
<body class="login-page">

<?php require __DIR__ . '/partials/visuel.php'; ?>

<main class="login-zone">
    <div class="auth-box">
        <a class="retour" href="../index.html"><i class="fa-solid fa-arrow-left"></i> Retour à l'accueil</a>
        <div class="tabs-login">
            <a class="tab-c" href="index.php?action=login">Connexion</a>
            <a class="tab-i actif" href="index.php?action=register">Créer un compte</a>
        </div>

        <section id="inscription">
            <h2>Rejoins TerraConnect 🌱</h2>
            <p class="sous">Crée ton compte gratuitement en moins d'une minute.</p>

            <?php foreach ($errors as $error): ?>
                <div class="msg msg-err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endforeach; ?>

            <form action="index.php?action=register" method="post">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                <div class="form-group full"><label for="i-nom">Nom d'utilisateur</label>
                    <div class="champ"><i class="fa-regular fa-user"></i><input id="i-nom" name="username" type="text" placeholder="Ex : mahmoud_j" autocomplete="off" minlength="3" maxlength="50" value="<?= htmlspecialchars($old['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required></div></div>
                <div class="form-group full"><label for="i-email">Email</label>
                    <div class="champ"><i class="fa-regular fa-envelope"></i><input id="i-email" name="email" type="email" placeholder="nom@exemple.tn" autocomplete="email" value="<?= htmlspecialchars($old['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required></div></div>
                <div class="form-group full"><label for="i-mdp">Mot de passe</label>
                    <div class="champ"><i class="fa-solid fa-lock"></i><input id="i-mdp" name="password" type="password" placeholder="8 caractères minimum" minlength="8" autocomplete="new-password" required></div></div>
                <div class="form-group full"><label for="i-mdp2">Confirmer le mot de passe</label>
                    <div class="champ"><i class="fa-solid fa-lock"></i><input id="i-mdp2" name="password_confirm" type="password" placeholder="Retape le mot de passe" minlength="8" autocomplete="new-password" required></div></div>
                <div class="form-group full"><button type="submit" class="btn-login"><i class="fa-solid fa-user-plus"></i> Créer mon compte</button></div>
            </form>
            <p class="bas">Déjà un compte ? <a href="index.php?action=login"><b>Se connecter</b></a></p>
        </section>
    </div>
</main>
</body>
</html>
