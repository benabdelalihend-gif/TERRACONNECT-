<section class="login-visuel">
    <a class="logo" href="../index.html"><img src="../logo.png" alt="Logo TerraConnect"><span>TerraConnect</span></a>
    <div class="login-texte">
        <h1>Soigne tes plantes,<br>fais-les <em>revivre</em></h1>
        <p>Déclare une plante malade, reconnais sa maladie grâce aux photos, reçois le bon traitement et suis sa guérison jour après jour.</p>
        <ul>
            <li><i class="fa-solid fa-camera"></i> Diagnostic par photos</li>
            <li><i class="fa-solid fa-flask"></i> Traitements adaptés</li>
            <li><i class="fa-solid fa-calendar-check"></i> Suivi quotidien</li>
        </ul>
    </div>
    <p class="login-copy">© 2026 TerraConnect - Agriculture durable</p>
</section>
