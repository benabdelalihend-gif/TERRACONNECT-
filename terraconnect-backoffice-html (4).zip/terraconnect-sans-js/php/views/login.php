<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TerraConnect - Connexion</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="assets/auth.css">
</head>
<body class="login-page">

<?php require __DIR__ . '/partials/visuel.php'; ?>

<main class="login-zone">
    <div class="auth-box">
        <a class="retour" href="../index.html"><i class="fa-solid fa-arrow-left"></i> Retour à l'accueil</a>
        <div class="tabs-login">
            <a class="tab-c actif" href="index.php?action=login">Connexion</a>
            <a class="tab-i" href="index.php?action=register">Créer un compte</a>
        </div>

        <section id="connexion">
            <h2>Bon retour parmi nous 👋</h2>
            <p class="sous">Connecte-toi pour retrouver tes plantes et tes traitements.</p>

            <?php if (!empty($sessionExpired)): ?>
                <div class="msg msg-info">Your session has expired. Please log in again.</div>
            <?php endif; ?>
            <?php if (!empty($registered)): ?>
                <div class="msg msg-ok">Account created. You can now log in.</div>
            <?php endif; ?>
            <?php foreach ($errors as $error): ?>
                <div class="msg msg-err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endforeach; ?>

            <form action="index.php?action=login" method="post">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                <div class="form-group full"><label for="c-email">Email</label>
                    <div class="champ"><i class="fa-regular fa-envelope"></i><input id="c-email" name="email" type="email" placeholder="nom@exemple.tn" autocomplete="email" value="<?= htmlspecialchars($old['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required></div></div>
                <div class="form-group full"><label for="c-mdp">Mot de passe</label>
                    <div class="champ"><i class="fa-solid fa-lock"></i><input id="c-mdp" name="password" type="password" placeholder="Ton mot de passe" autocomplete="current-password" required></div></div>
                <div class="form-group full"><button type="submit" class="btn-login"><i class="fa-solid fa-right-to-bracket"></i> Se connecter</button></div>
            </form>
            <p class="bas">Pas encore de compte ? <a href="index.php?action=register"><b>Créer un compte</b></a></p>
        </section>
    </div>
</main>
</body>
</html>
