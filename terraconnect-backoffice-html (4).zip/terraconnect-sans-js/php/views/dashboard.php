<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TerraConnect - Mon espace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="assets/auth.css">
</head>
<body>
<main class="espace">
    <h1>Bienvenue,
        <?= htmlspecialchars($user->getUsername(), ENT_QUOTES, 'UTF-8') ?> 🌿</h1>
    <p>Email : <?= htmlspecialchars($user->getEmail(), ENT_QUOTES, 'UTF-8') ?></p>
    <p>Rôle : <b><?= htmlspecialchars($user->getRole(), ENT_QUOTES, 'UTF-8') ?></b></p>

    <div class="espace-actions">
        <a class="btn-login lien-btn" href="../frontoffice/tableau-de-bord.html"><i class="fa-solid fa-seedling"></i> Mes plantes</a>
        <?php if ($user->getRole() === 'admin'): ?>
            <a class="btn-login lien-btn" href="index.php?action=admin"><i class="fa-solid fa-user-shield"></i> Administration</a>
        <?php endif; ?>
        <form action="index.php?action=logout" method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
            <button type="submit" class="btn-login"><i class="fa-solid fa-right-from-bracket"></i> Se déconnecter</button>
        </form>
    </div>
</main>
</body>
</html>
