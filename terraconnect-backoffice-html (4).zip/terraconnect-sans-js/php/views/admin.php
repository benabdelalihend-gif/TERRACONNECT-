<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TerraConnect - Administration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="assets/auth.css">
</head>
<body>
<main class="espace espace-large">
    <h1>Administration</h1>
    <p>Connecté en tant que <b><?= htmlspecialchars($user->getUsername(), ENT_QUOTES, 'UTF-8') ?></b>.</p>

    <div class="table-scroll">
        <table class="table-users">
            <thead><tr><th>ID</th><th>Utilisateur</th><th>Email</th><th>Rôle</th></tr></thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u->getId() ?></td>
                    <td><?= htmlspecialchars($u->getUsername(), ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($u->getEmail(), ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($u->getRole(), ENT_QUOTES, 'UTF-8') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="espace-actions">
        <a class="btn-login lien-btn" href="index.php?action=dashboard"><i class="fa-solid fa-arrow-left"></i> Mon espace</a>
        <form action="index.php?action=logout" method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
            <button type="submit" class="btn-login"><i class="fa-solid fa-right-from-bracket"></i> Se déconnecter</button>
        </form>
    </div>
</main>
</body>
</html>
