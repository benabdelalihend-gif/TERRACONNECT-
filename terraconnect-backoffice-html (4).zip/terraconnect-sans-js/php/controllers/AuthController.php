<?php
declare(strict_types=1);

final class AuthController
{
    public function __construct(private PDO $db)
    {
    }

    // ==============================================================
    // CSRF (7.4)
    // ==============================================================
    public function getCsrfToken(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    private function verifyCsrfToken(?string $token): bool
    {
        if (!$token || empty($_SESSION['csrf_token'])) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }

    // ==============================================================
    // Inscription
    // ==============================================================
    /** @return string[] liste d'erreurs (vide = compte créé) */
    public function register(array $post): array
    {
        $errors = [];

        if (!$this->verifyCsrfToken($post['csrf_token'] ?? null)) {
            $errors[] = "Invalid security token. Please try again.";
            return $errors;
        }

        $username  = trim((string) ($post['username'] ?? ''));
        $email     = trim((string) ($post['email'] ?? ''));
        $password  = (string) ($post['password'] ?? '');
        $password2 = (string) ($post['password_confirm'] ?? '');

        // 1re barrière XSS : validation des entrées
        if (!preg_match('/^[A-Za-z0-9_-]{3,50}$/', $username)) {
            $errors[] = "Username must be 3 to 50 characters (letters, digits, _ or -).";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 255) {
            $errors[] = "Invalid email address.";
        }
        if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters.";
        }
        if ($password !== $password2) {
            $errors[] = "Passwords do not match.";
        }
        if ($errors) {
            return $errors;
        }

        $stmt = $this->db->prepare(
            'SELECT id FROM users WHERE email = :email OR username = :username LIMIT 1'
        );
        $stmt->execute(['email' => $email, 'username' => $username]);
        if ($stmt->fetch()) {
            return ["This email or username is already used."];
        }

        // 7.1 : toute création de compte passe par password_hash()
        // 7.6 : le rôle est FORCÉ à 'user' (jamais lu depuis $post)
        try {
            $stmt = $this->db->prepare(
                'INSERT INTO users (username, email, password, role)
                 VALUES (:username, :email, :password, :role)'
            );
            $stmt->execute([
                'username' => $username,
                'email'    => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'role'     => 'user',
            ]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') { // doublon (deux inscriptions simultanées)
                return ["This email or username is already used."];
            }
            throw $e;
        }

        return [];
    }

    // ==============================================================
    // Connexion
    // ==============================================================
    /** @return string[] liste d'erreurs (vide = connecté) */
    public function login(array $post): array
    {
        $errors = [];

        if (!$this->verifyCsrfToken($post['csrf_token'] ?? null)) {
            $errors[] = "Invalid security token. Please try again.";
            return $errors;
        }

        $email    = trim((string) ($post['email'] ?? ''));
        $password = (string) ($post['password'] ?? '');

        // Requête préparée : ' OR '1'='1 est traité comme une simple donnée (7.2)
        $stmt = $this->db->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => $email]);
        $row = $stmt->fetch();

        if (!$row || !password_verify($password, $row['password'])) {
            return ["Incorrect email or password."];
        }

        $user = User::fromRow($row);

        // Anti fixation de session
        session_regenerate_id(true);
        $_SESSION['user_id']       = $user->getId();
        $_SESSION['role']          = $user->getRole();
        $_SESSION['last_activity'] = time();
        unset($_SESSION['csrf_token']); // nouveau token après connexion

        return [];
    }

    // ==============================================================
    // Déconnexion (POST + CSRF : un simple lien ne peut pas déconnecter)
    // ==============================================================
    public function logout(array $post): void
    {
        if ($this->verifyCsrfToken($post['csrf_token'] ?? null)) {
            $_SESSION = [];
            if (ini_get('session.use_cookies')) {
                $p = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
            }
            session_destroy();
        }
    }

    // ==============================================================
    // Accès / rôles
    // ==============================================================
    public function currentUser(): ?User
    {
        if (empty($_SESSION['user_id'])) {
            return null;
        }
        $stmt = $this->db->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => (int) $_SESSION['user_id']]);
        $row = $stmt->fetch();

        return $row ? User::fromRow($row) : null;
    }

    public function requireLogin(): User
    {
        $user = $this->currentUser();
        if ($user === null) {
            header('Location: index.php?action=login');
            exit;
        }
        return $user;
    }

    /** Bloque la page si l'utilisateur n'a pas le rôle demandé. */
    public function requireRole(string $role): User
    {
        $user = $this->requireLogin();
        if ($user->getRole() !== $role) {
            http_response_code(403);
            echo '403 - Access denied.';
            exit;
        }
        return $user;
    }

    /** @return User[] */
    public function getAllUsers(): array
    {
        $rows = $this->db->query('SELECT * FROM users ORDER BY id')->fetchAll();
        return array_map([User::class, 'fromRow'], $rows);
    }
}
