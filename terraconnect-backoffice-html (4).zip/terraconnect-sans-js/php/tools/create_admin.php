<?php
declare(strict_types=1);

// Usage (terminal uniquement) : php tools/create_admin.php admin admin@exemple.tn "MotDePasse!2026"
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('CLI only.');
}
if ($argc !== 4) {
    exit("Usage: php tools/create_admin.php <username> <email> <password>\n");
}

require_once __DIR__ . '/../config/database.php';
[, $username, $email, $password] = $argv;

if (!preg_match('/^[A-Za-z0-9_-]{3,50}$/', $username) || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
    exit("Invalid username, email or password (8 characters minimum).\n");
}

$stmt = getDatabase()->prepare(
    'INSERT INTO users (username, email, password, role) VALUES (:u, :e, :p, :r)'
);
$stmt->execute([
    'u' => $username,
    'e' => $email,
    'p' => password_hash($password, PASSWORD_DEFAULT), // 7.1
    'r' => 'admin',
]);
echo "Admin '$username' created.\n";
