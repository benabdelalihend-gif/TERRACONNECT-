<?php
declare(strict_types=1);

final class User
{
    public function __construct(
        private int $id,
        private string $username,
        private string $email,
        private string $passwordHash,
        private string $role
    ) {
    }

    public static function fromRow(array $row): self
    {
        return new self(
            (int) $row['id'],
            (string) $row['username'],
            (string) $row['email'],
            (string) $row['password'],
            (string) $row['role']
        );
    }

    public function getId(): int { return $this->id; }
    public function getUsername(): string { return $this->username; }
    public function getEmail(): string { return $this->email; }
    public function getPasswordHash(): string { return $this->passwordHash; }
    public function getRole(): string { return $this->role; }
}
