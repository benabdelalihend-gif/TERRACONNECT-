<?php
declare(strict_types=1);

// ==============================================================
// 1. Configuration sécurisée de la session (5.5)
// ==============================================================
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');   // cookie invisible pour JavaScript
ini_set('session.cookie_samesite', 'Lax'); // limite l'envoi du cookie depuis un site tiers
// Si le site est servi en HTTPS, décommente la ligne suivante (7.5) :
// ini_set('session.cookie_secure', '1');
session_start();

// ==============================================================
// 2. Expiration de la session après 30 min d'inactivité (5.5)
// ==============================================================
$sessionExpired = false;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > 1800) {
    $_SESSION = [];
    session_destroy();
    session_start();
    $sessionExpired = true;
}
if (!empty($_SESSION['user_id'])) {
    $_SESSION['last_activity'] = time();
}

// ==============================================================
// 3. En-têtes HTTP de sécurité (7.5)
// ==============================================================
header('X-Frame-Options: DENY');            // anti clickjacking
header('X-Content-Type-Options: nosniff');  // empêche le MIME-sniffing
header('Referrer-Policy: strict-origin-when-cross-origin');
// Limite les sources chargeables (2e barrière contre le XSS).
// cdnjs est autorisé uniquement pour les icônes Font Awesome du design.
header("Content-Security-Policy: default-src 'self'; "
     . "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; "
     . "font-src 'self' https://cdnjs.cloudflare.com; "
     . "img-src 'self' data:");

// ==============================================================
// 4. Dépendances
// ==============================================================
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/models/User.php';
require_once __DIR__ . '/controllers/AuthController.php';

$authController = new AuthController(getDatabase());

// ==============================================================
// 5. Routage
// ==============================================================
$action = $_GET['action'] ?? 'login';
$errors = [];
$old    = [];

switch ($action) {
    case 'register':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $errors = $authController->register($_POST);
            if (!$errors) {
                header('Location: index.php?action=login&registered=1');
                exit;
            }
            $old = [
                'username' => (string) ($_POST['username'] ?? ''),
                'email'    => (string) ($_POST['email'] ?? ''),
            ];
        }
        $csrfToken = $authController->getCsrfToken();
        require __DIR__ . '/views/register.php';
        break;

    case 'login':
        if ($authController->currentUser() !== null) {
            header('Location: index.php?action=dashboard');
            exit;
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $errors = $authController->login($_POST);
            if (!$errors) {
                header('Location: index.php?action=dashboard');
                exit;
            }
            $old = ['email' => (string) ($_POST['email'] ?? '')];
        }
        $registered = isset($_GET['registered']);
        $csrfToken = $authController->getCsrfToken();
        require __DIR__ . '/views/login.php';
        break;

    case 'dashboard':
        $user = $authController->requireLogin();
        $csrfToken = $authController->getCsrfToken();
        require __DIR__ . '/views/dashboard.php';
        break;

    case 'admin':
        $user = $authController->requireRole('admin');
        $users = $authController->getAllUsers();
        $csrfToken = $authController->getCsrfToken();
        require __DIR__ . '/views/admin.php';
        break;

    case 'logout':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $authController->logout($_POST);
        }
        header('Location: index.php?action=login');
        exit;

    default:
        http_response_code(404);
        echo '404 - Page not found.';
}
