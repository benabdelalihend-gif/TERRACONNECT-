<?php
declare(strict_types=1);

/**
 * Connexion PDO.
 * ATTR_EMULATE_PREPARES = false : les requêtes préparées sont exécutées côté
 * serveur MySQL, la donnée n'est donc JAMAIS mélangée au code SQL (anti-injection).
 */
function getDatabase(): PDO
{
    $host = 'localhost';
    $name = 'terraconnect';
    $user = 'root';
    $pass = '';

    $dsn = "mysql:host=$host;dbname=$name;charset=utf8mb4";

    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
}
