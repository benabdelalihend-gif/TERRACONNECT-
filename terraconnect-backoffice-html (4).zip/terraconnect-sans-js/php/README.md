# TerraConnect – authentification PHP sécurisée (Partie 7)

## Installation
1. Importer `sql/schema.sql` dans MySQL (phpMyAdmin → onglet SQL).
2. Adapter les identifiants dans `config/database.php`.
3. Créer un admin : `php tools/create_admin.php admin admin@exemple.tn "MotDePasse!2026"`.
4. Servir le dossier **parent** (`terraconnect-sans-js/`) avec Apache/XAMPP ou
   `php -S localhost:8000` depuis ce dossier parent, puis ouvrir
   `http://localhost:8000/php/index.php`.
   (Les pages utilisent `../css/style.css` et `../logo.png`.)

## Où est la Partie 7 ?
| Point | Fichier |
|---|---|
| 7.1 Hachage | `AuthController::register()`, `tools/create_admin.php` |
| 7.2 Injection SQL | requêtes préparées dans `AuthController`, `ATTR_EMULATE_PREPARES=false` dans `config/database.php` |
| 7.3 XSS | `htmlspecialchars()` dans toutes les vues, validation du nom d'utilisateur, `sql/test_xss.sql` |
| 7.4 CSRF | `getCsrfToken()` / `verifyCsrfToken()`, champ caché dans `views/login.php`, `register.php` (et logout) |
| 7.5 En-têtes HTTP | `index.php` (bloc 3) |
| 7.6 Rôles, fixation, expiration | `register()` (rôle forcé à `user`), `login()` (`session_regenerate_id`), `requireRole()`, `index.php` |

## Écart avec le cours
La Content-Security-Policy autorise en plus `https://cdnjs.cloudflare.com`
(icônes Font Awesome du design) et les images `data:`. Retire ces ajouts si tu supprimes Font Awesome.
