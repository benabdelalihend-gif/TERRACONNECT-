<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$dataDir = dirname(__DIR__) . '/data';
$file = $dataDir . '/conseils.json';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
if (!file_exists($file)) file_put_contents($file, '[]');

function respond(int $status, array $payload): never {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}
function loadAdvice(string $file): array {
    $items = json_decode((string)file_get_contents($file), true);
    return is_array($items) ? $items : [];
}
function saveAdvice(string $file, array $items): void {
    $json = json_encode(array_values($items), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false || file_put_contents($file, $json, LOCK_EX) === false) {
        respond(500, ['error' => 'Impossible d’enregistrer les conseils.']);
    }
}
function cleanField(array $body, string $key, int $max): string {
    $value = trim((string)($body[$key] ?? ''));
    if (mb_strlen($value) > $max) respond(422, ['error' => "Le champ $key est trop long."]);
    return $value;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$items = loadAdvice($file);

if ($method === 'GET') {
    $publishedOnly = ($_GET['published'] ?? '') === '1';
    if ($publishedOnly) $items = array_values(array_filter($items, fn($a) => ($a['status'] ?? '') === 'Publié'));
    respond(200, ['advice' => $items]);
}

if (!in_array($method, ['POST', 'PUT', 'DELETE'], true)) {
    header('Allow: GET, POST, PUT, DELETE');
    respond(405, ['error' => 'Méthode non autorisée.']);
}

$body = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($body)) respond(400, ['error' => 'Données JSON invalides.']);

if ($method === 'DELETE') {
    $id = filter_var($body['id'] ?? null, FILTER_VALIDATE_INT);
    if (!$id) respond(422, ['error' => 'Identifiant invalide.']);
    $before = count($items);
    $items = array_values(array_filter($items, fn($a) => (int)($a['id'] ?? 0) !== $id));
    if (count($items) === $before) respond(404, ['error' => 'Conseil introuvable.']);
    saveAdvice($file, $items);
    respond(200, ['success' => true, 'advice' => $items]);
}

$title = cleanField($body, 'title', 120);
$category = cleanField($body, 'category', 40);
$description = cleanField($body, 'description', 2000);
$crops = cleanField($body, 'crops', 250);
$seasons = cleanField($body, 'seasons', 120);
$status = cleanField($body, 'status', 20);
if ($title === '' || $description === '') respond(422, ['error' => 'Le titre et la description sont obligatoires.']);
if (!in_array($category, ['Irrigation', 'Protection', 'Fertilisation'], true)) respond(422, ['error' => 'Catégorie invalide.']);
if (!in_array($status, ['Publié', 'Brouillon'], true)) respond(422, ['error' => 'Statut invalide.']);

$item = ['title'=>$title, 'category'=>$category, 'description'=>$description,
         'crops'=>$crops !== '' ? $crops : 'Toutes', 'seasons'=>$seasons !== '' ? $seasons : 'Toute l’année', 'status'=>$status];

if ($method === 'POST') {
    $nextId = empty($items) ? 1 : max(array_map(fn($a) => (int)($a['id'] ?? 0), $items)) + 1;
    $item['id'] = $nextId;
    $items[] = $item;
} else {
    $id = filter_var($body['id'] ?? null, FILTER_VALIDATE_INT);
    if (!$id) respond(422, ['error' => 'Identifiant invalide.']);
    $found = false;
    foreach ($items as $index => $existing) {
        if ((int)($existing['id'] ?? 0) === $id) {
            $item['id'] = $id;
            $items[$index] = $item;
            $found = true;
            break;
        }
    }
    if (!$found) respond(404, ['error' => 'Conseil introuvable.']);
}
saveAdvice($file, $items);
respond(200, ['success' => true, 'advice' => $items]);
